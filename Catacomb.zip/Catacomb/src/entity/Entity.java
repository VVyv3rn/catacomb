package entity;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Random;

import main.GamePanel;

public class Entity {

    public static GamePanel gp;
    public ArrayList<Entity> inventory = new ArrayList<>();

    public final static int inventorySize = 63;

    public int worldX, worldY;

    public BufferedImage walkingNorthwest, walkingNorthwest2, walkingNorthwest3, walkingNorthwest4;
    public BufferedImage walkingNorth, walkingNorth2, walkingNorth3, walkingNorth4;
    public BufferedImage walkingNortheast, walkingNortheast2, walkingNortheast3, walkingNortheast4;
    public BufferedImage walkingEast, walkingEast2, walkingEast3, walkingEast4;
    public BufferedImage walkingSoutheast, walkingSoutheast2, walkingSoutheast3, walkingSoutheast4;
    public BufferedImage walkingSouth, walkingSouth2, walkingSouth3, walkingSouth4;
    public BufferedImage walkingSouthwest, walkingSouthwest2, walkingSouthwest3, walkingSouthwest4;
    public BufferedImage walkingWest, walkingWest2, walkingWest3, walkingWest4;

    public BufferedImage attackNorth, attackNorth2;
    public BufferedImage attackSouth, attackSouth2;
    public BufferedImage attackWest, attackWest2;
    public BufferedImage attackEast, attackEast2;
    public BufferedImage attackNortheast, attackNortheast2;
    public BufferedImage attackNorthwest, attackNorthwest2;
    public BufferedImage attackSoutheast, attackSoutheast2;
    public BufferedImage attackSouthwest, attackSouthwest2;

    public boolean attacking = false;
    public Rectangle attackArea = new Rectangle(0, 0, 0, 0);

    public BufferedImage facingNorthwest;
    public BufferedImage facingNorth;
    public BufferedImage facingNortheast;
    public BufferedImage facingEast;
    public BufferedImage facingSoutheast;
    public BufferedImage facingSouth;
    public BufferedImage facingSouthwest;
    public BufferedImage facingWest;
    public BufferedImage error;
    public String direction = "South";

    public int movementCounter = 0;
    public int movementNum = 1;

    public int attackCounter = 0;
    public int attackNum = 1;

    public Rectangle solidArea = new Rectangle(0, 0, 64, 64);

    public BufferedImage image, image2, image3;
    public String name;
    public boolean collision = false;
    public int type; // 0 is player, 1 is npc, 2 is monster
    public String description;

    public boolean collisionOn = false;
    public int actionLockCounter = 0;
    public boolean invincible = false;
    public int invincibleCounter = 0;
    int dyingCounter = 0;
    int hpBarCounter = 0;

    String dialogues[] = new String[20];
    int dialogueIndex = 0;
    public static boolean oldmanTalkedTo = false;

    public boolean collisionNorth = false;
    public boolean collisionSouth = false;
    public boolean collisionWest = false;
    public boolean collisionEast = false;

    public int solidAreaDefaultX, solidAreaDefaultY;

    public boolean alive = true;
    public boolean dying = false;
    public boolean hasAI = true;
    int deathAnimationInterval = 5;
    public boolean hpBarOn = false;

    // PLAYER ATTRIBUTES
    public int speed;
    public int maxLife;
    public int life;
    public int level;
    public int strength;
    public int dexterity;
    public int attack;
    public int defense;
    public int exp;
    public double nextLevelExp;
    public double lastLevelExp;
    public String fixedNextLevelExp;
    public int coin;
    public Entity currentWeapon;
    public Entity currentShield;
    public Entity currentHelmet;
    public Entity currentChestplate;
    public Entity currentLeggings;
    public Entity currentBoots;
    public Entity currentBauble1;
    public Entity currentBauble2;
    public Entity currentBauble3;
    public Entity currentBauble4;

    // ITEM ATTRIBUTES
    public int attackValue;
    public int defenseValue;

    public static boolean randomSpawning = true;

    public Entity(GamePanel gp) {
        Entity.gp = gp;
    }

    public static void randomSpawning() {
        if (randomSpawning == true) {
            int maxIndex = 0;
            while (gp.allMonster[maxIndex] != null) {
                maxIndex++;
            }
            for (int i = 0; i < gp.monster.length; i++) {
                if (gp.monster[i] == null) {
                    Random random = new Random();

                    int rIndex = random.nextInt(maxIndex);
                    int rSpawnX = random.nextInt(gp.maxWorldWidth - 28) + 3;
                    int rSpawnY = random.nextInt(gp.maxWorldHeight -28) + 3;

                    

                    gp.monster[i] = gp.allMonster[rIndex];
                    gp.monster[i].worldX = rSpawnX;
                    gp.monster[i].worldY = rSpawnY;
                    gp.monster[i].hasAI = true;
                }
            }
        }
    }

    public void setAction() {
        Random random = new Random();
        attack = 1 + (gp.player.level * 2 / (gp.player.level));
        if (actionLockCounter > 120) {
            int i = random.nextInt(200) + 1; // pick random number from 1 to 100

            if (i <= 25) {
                direction = "North";
            }
            if (i > 25 && i <= 50) {
                direction = "South";
            }
            if (i > 50 && i <= 75) {
                direction = "West";
            }
            if (i > 75 && i <= 100) {
                direction = "East";
            }
            if (i > 100 && i <= 125) {
                direction = "Northwest";
            }
            if (i > 125 && i <= 150) {
                direction = "Northeast";
            }
            if (i > 150 && i <= 175) {
                direction = "Southwest";
            }
            if (i > 175 && i <= 200) {
                direction = "Southeast";
            }

            actionLockCounter = 0;
        }
        actionLockCounter++;
    }

    public void damageReaction() {
        actionLockCounter = 0;

        direction = gp.player.direction;
    }

    public void speak() {

    }

    public void update() {

        setAction();

        collisionOn = false;
        gp.cChecker.checkTile(this);
        gp.cChecker.checkObject(this, false);
        gp.cChecker.checkEntity(this, gp.npc);
        gp.cChecker.checkEntity(this, gp.monster);
        boolean contactPlayer = gp.cChecker.checkPlayer(this);

        if (this.type == 2 && contactPlayer == true) {
            if (gp.player.invincible == false) {
                // give damage if previous conditions are met
                int damage = attack - gp.player.defense;
                if (damage < 0) {
                    damage = 0;
                }
                gp.player.life -= damage;

                gp.player.invincible = true;
            }
        }
        if (collisionOn == false && hasAI == true) {
            switch (direction) {
                case "North":
                    worldY -= speed;
                    break;
                case "South":
                    worldY += speed;
                    break;
                case "West":
                    worldX -= speed;
                    break;
                case "East":
                    worldX += speed;
                    break;
                case "Northwest":
                    worldX -= speed;
                    worldY -= speed;
                    break;
                case "Northeast":
                    worldX += speed;
                    worldY -= speed;
                    break;
                case "Southwest":
                    worldX -= speed;
                    worldY += speed;
                    break;
                case "Southeast":
                    worldX += speed;
                    worldY += speed;
                    break;
            }
        }

        if (movementCounter > 12) {
            if (movementNum == 1) {
                movementNum = 2;
            } else if (movementNum == 2) {
                movementNum = 3;
            } else if (movementNum == 3) {
                movementNum = 4;
            } else if (movementNum == 4) {
                movementNum = 1;
            }
            movementCounter = 0;

        }

        // invincible timing | THIS MUST BE OUTSIDE THE IF STATEMENTS
        if (invincible == true) {
            invincibleCounter++;
            if (invincibleCounter > 30) {
                invincible = false;
                invincibleCounter = 0;
            }
        }
    }

    public void draw(Graphics2D g2) {
        int screenX = worldX - gp.player.worldX + gp.player.screenX;
        int screenY = worldY - gp.player.worldY + gp.player.screenY;

        BufferedImage image = null;
        if (gp.keyH.debug == true) {
            g2.setColor(Color.red);
            g2.drawRect(screenX + solidArea.x, screenY + solidArea.y, solidArea.width, solidArea.height);

        }

        switch (direction) {
            case "North":
                if (movementNum == 1) {
                    image = walkingNorth;
                }
                if (movementNum == 2) {
                    image = walkingNorth2;
                }
                if (movementNum == 3) {
                    image = walkingNorth;
                }
                if (movementNum == 4) {
                    image = walkingNorth2;
                }
                break;
            case "South":
                if (movementNum == 1) {
                    image = walkingSouth;
                }
                if (movementNum == 2) {
                    image = walkingSouth2;
                }
                if (movementNum == 3) {
                    image = walkingSouth;
                }
                if (movementNum == 4) {
                    image = walkingSouth2;
                }
                break;
            case "West":
                if (movementNum == 1) {
                    image = walkingWest;
                }
                if (movementNum == 2) {
                    image = walkingWest2;
                }
                if (movementNum == 3) {
                    image = walkingWest;
                }
                if (movementNum == 4) {
                    image = walkingWest2;
                }
                break;
            case "East":
                if (movementNum == 1) {
                    image = walkingEast;
                }
                if (movementNum == 2) {
                    image = walkingEast2;
                }
                if (movementNum == 3) {
                    image = walkingEast;
                }
                if (movementNum == 4) {
                    image = walkingEast2;
                }
                break;
            case "Northeast":
                if (movementNum == 1) {
                    image = walkingNortheast;
                }
                if (movementNum == 2) {
                    image = walkingNortheast2;
                }
                if (movementNum == 3) {
                    image = walkingNortheast3;
                }
                if (movementNum == 4) {
                    image = walkingNortheast4;
                }
                break;
            case "Northwest":
                if (movementNum == 1) {
                    image = walkingNorthwest;
                }
                if (movementNum == 2) {
                    image = walkingNorthwest2;
                }
                if (movementNum == 3) {
                    image = walkingNorthwest3;
                }
                if (movementNum == 4) {
                    image = walkingNorthwest4;
                }
            case "Southeast":
                if (movementNum == 1) {
                    image = walkingSoutheast;
                }
                if (movementNum == 2) {
                    image = walkingSoutheast2;
                }
                if (movementNum == 3) {
                    image = walkingSoutheast3;
                }
                if (movementNum == 4) {
                    image = walkingSoutheast4;
                }
                break;
            case "Southwest":
                if (movementNum == 1) {
                    image = walkingSouthwest;
                }
                if (movementNum == 2) {
                    image = walkingSouthwest2;
                }
                if (movementNum == 3) {
                    image = walkingSouthwest3;
                }
                if (movementNum == 4) {
                    image = walkingSouthwest4;
                }
                break;

        }

        // monster heatlh bar
        if (type == 2 && hpBarOn == true) {

            double oneScale = (double) gp.tileSize / maxLife;
            double hpBarValue = oneScale * life;

            g2.setColor(new Color(35, 35, 35));
            g2.fillRect(screenX - 1, screenY - 16, gp.tileSize + 2, 12);

            g2.setColor(new Color(255, 0, 30));
            if ((int) hpBarValue > 0) {
                g2.fillRect(screenX, screenY - 15, (int) hpBarValue, 10);
            } else if (hpBarValue <= 0) {
                g2.fillRect(screenX, screenY - 15, 0, 10);
            }

            hpBarCounter++;

            if (hpBarCounter > 600) {
                hpBarCounter = 0;
                hpBarOn = false;
            }

        }

        if (invincible == true) {
            hpBarOn = true;
            hpBarCounter = 0;
        }
        if (dying == true) {
            dyingAnimation(g2);
        }

        g2.drawImage(image, screenX, screenY, gp.tileSize, gp.tileSize, null);

    }

    public void dyingAnimation(Graphics2D g2) {

        dyingCounter++;

        if (dyingCounter <= deathAnimationInterval) {
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0f));
        }
        if (dyingCounter > deathAnimationInterval && dyingCounter <= deathAnimationInterval * 2) {
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
        }
        if (dyingCounter > deathAnimationInterval * 2 && dyingCounter <= deathAnimationInterval * 3) {
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0f));
        }
        if (dyingCounter > deathAnimationInterval * 3 && dyingCounter <= deathAnimationInterval * 4) {
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
        }
        if (dyingCounter > deathAnimationInterval * 4 && dyingCounter <= deathAnimationInterval * 5) {
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0f));
        }
        if (dyingCounter > deathAnimationInterval * 5 && dyingCounter <= deathAnimationInterval * 6) {
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
        }
        if (dyingCounter > deathAnimationInterval * 6 && dyingCounter <= deathAnimationInterval * 7) {
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0f));
        }
        if (dyingCounter > deathAnimationInterval * 7 && dyingCounter <= deathAnimationInterval * 8) {
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
        }
        if (dyingCounter > deathAnimationInterval * 8) {
            dying = false;
            alive = false;
        }
    }

    boolean bufferedImagesEqual(BufferedImage img1, BufferedImage img2) {
        if (img1.getWidth() == img2.getWidth() && img1.getHeight() == img2.getHeight()) {
            for (int x = 0; x < img1.getWidth(); x++) {
                for (int y = 0; y < img1.getHeight(); y++) {
                    if (img1.getRGB(x, y) != img2.getRGB(x, y))
                        return false;
                }
            }
        } else {
            return false;
        }
        return true;
    }

}
