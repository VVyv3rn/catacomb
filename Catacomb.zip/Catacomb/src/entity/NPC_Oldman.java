package entity;

import java.io.File;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;

import main.GamePanel;

public class NPC_Oldman extends Entity {

    public NPC_Oldman(GamePanel gp) {
        super(gp);

        direction = "South";
        speed = 1;
        getOldmanImage();
        setDialogue();
    }

    public void getOldmanImage() {

        try {
            walkingNorth = ImageIO.read(new File("src/assets/entityassets/npc/oldman/oldman_north_1.png"));
            walkingNorth2 = ImageIO.read(new File("src/assets/entityassets/npc/oldman/oldman_north_2.png"));

            walkingSouth = ImageIO.read(new File("src/assets/entityassets/npc/oldman/oldman_south_1.png"));
            walkingSouth2 = ImageIO.read(new File("src/assets/entityassets/npc/oldman/oldman_south_2.png"));

            walkingEast = ImageIO.read(new File("src/assets/entityassets/npc/oldman/oldman_east_1.png"));
            walkingEast2 = ImageIO.read(new File("src/assets/entityassets/npc/oldman/oldman_east_2.png"));

            walkingWest = ImageIO.read(new File("src/assets/entityassets/npc/oldman/oldman_west_1.png"));
            walkingWest2 = ImageIO.read(new File("src/assets/entityassets/npc/oldman/oldman_west_2.png"));

            error = ImageIO.read(new File("src/assets/error.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void setDialogue() {
        dialogues[0] = "Hello, adventurer.";
        dialogues[1] = "You know, this village has \nsome secrets hidden deep  \nbelow it";
        dialogues[2] = "What secrets? You may ask?";
        dialogues[3] = "Well, deep below the village \nthere's a place called the \nCatacombs.";
        dialogues[4] = "The Catacombs are said to \ncontain valuable treasures, \nsome may even contain \nimmense power.";
        dialogues[5] = "It is said the most valuable \ntreasure within the Catacombs \nis the <InsertItem>";
        dialogues[6] = "I would go down in search of \nthe <InsertItem> myself, \nbut I'm far too old for adventures \nlike that these days.";
        dialogues[7] = "Well, I wish you luck on your \njourney through the Catacombs";
        dialogues[8] = "Take this old sword to aid you \nin your travels";

        dialogues[19] = "Good luck on your journey";
    }
    public void setAction() {
        actionLockCounter++;

        if(actionLockCounter == 120) {
            Random random = new Random();
            int i = random.nextInt(100)+1; // pick random number from 1 to 100
    
            if(i <= 25) {
                direction = "North";
            }
            if(i > 25 && i <= 50) {
                direction = "South";
            }
            if(i > 50 && i <= 75) {
                direction = "West";
            }
            if(i > 75 && i <= 100) {
                direction = "East";
            }

            actionLockCounter = 0;
        }

        
    }
    

    public void speak() {


        if(dialogues[dialogueIndex] == null) {
            gp.keyH.ePressed = false;
            oldmanTalkedTo = true;
            gp.ui.currentDialogue = dialogues[19];
        }
        if(oldmanTalkedTo == false) {
            gp.ui.currentDialogue = dialogues[dialogueIndex];
            dialogueIndex++;
        }
        
        
        

        switch(gp.player.direction) {
            case "North":
            direction = "South";
            break;
            case "South":
            direction = "North";
            break;
            case "West":
            direction = "East";
            break;
            case "East":
            direction = "West";
            break;
            case "Northeast":
            direction = "South";
            break;
            case"Northwest":
            direction = "South";
            break;
            case "Southeast":
            direction = "North";
            break;
            case "Southwest":
            direction = "North";
            break;
        }
    }
}
