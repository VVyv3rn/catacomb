package entity;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;

import javax.imageio.ImageIO;

import main.GamePanel;
import main.KeyHandler;
import object.OBJ_Key;
import object.weapon.SHD_Default_Shield;
import object.weapon.WPN_Default_Sword;

public class Player extends Entity {

    GamePanel gp;
    KeyHandler keyH;

    public int screenX;
    public int screenY;

    public String classType;

    public Player(GamePanel gp, KeyHandler keyH) {

        super(gp);

        this.gp = gp;
        this.keyH = keyH;

        screenX = gp.screenWidth / 2 - (gp.tileSize / 2);
        screenY = gp.screenHeight / 2 - (gp.tileSize / 2);

        solidArea = new Rectangle();
        solidArea.x = 40;
        solidArea.y = 80;
        solidAreaDefaultX = solidArea.x;
        solidAreaDefaultY = solidArea.y;
        solidArea.width = 12 * gp.nonStaticScale;
        solidArea.height = gp.tileSize / 2;

        
        attackArea.width = gp.tileSize - (gp.tileSize / 4);
        attackArea.height = gp.tileSize - (gp.tileSize / 4);


        setDefaultValues();
        getPlayerImage();
        getPlayerAttackImage();
        setItems();
    }

    public void setDefaultValues() {
        worldX = gp.tileSize * 3;
        worldY = gp.tileSize * 7;
        speed = 4;
        direction = "South";

        // PLAYER STATUS
        maxLife = 6;
        life = maxLife;

        level = 1;
        strength = 1; // more strength = more damage
        dexterity = 1;  //more dexterity = less damage received
        exp = 0;
        nextLevelExp = 10;
        fixedNextLevelExp = String.valueOf(nextLevelExp);
        coin = 0;
        currentWeapon = new WPN_Default_Sword(gp);
        currentShield = new SHD_Default_Shield(gp);
        attack = getAttack();
        defense = getDefense();
    }
    public void setItems() {
        inventory.add(currentWeapon);
        inventory.add(currentShield);
        inventory.add(new OBJ_Key());
    }

    public int getAttack() {
        return attack = strength * currentWeapon.attackValue;
    }
    public int getDefense() {
        return defense = dexterity * currentShield.defenseValue;
    }

    public void getPlayerImage() {

        try {

            // create variables for facing a direction

            facingNorth = ImageIO.read(new File("src/assets/playerassets/redhead/walkingN3.png"));
            facingSouth = ImageIO.read(new File("src/assets/playerassets/redhead/walkingS3.png"));
            facingWest = ImageIO.read(new File("src/assets/playerassets/redhead/walkingW3.png"));
            facingEast = ImageIO.read(new File("src/assets/playerassets/redhead/walkingE3.png"));

            facingNortheast = ImageIO.read(new File("src/assets/playerassets/redhead/walkingNE2.png"));
            facingNorthwest = ImageIO.read(new File("src/assets/playerassets/redhead/walkingNw3.png"));
            facingSoutheast = ImageIO.read(new File("src/assets/playerassets/redhead/walkingSE3.png"));
            facingSouthwest = ImageIO.read(new File("src/assets/playerassets/redhead/walkingSW3.png"));

            // create variables for the directional walking images

            walkingNortheast = ImageIO.read(new File("src/assets/playerassets/redhead/walkingNE.png"));
            walkingNortheast2 = ImageIO.read(new File("src/assets/playerassets/redhead/walkingNE2.png"));
            walkingNortheast3 = ImageIO.read(new File("src/assets/playerassets/redhead/walkingNE3.png"));
            walkingNortheast4 = ImageIO.read(new File("src/assets/playerassets/redhead/walkingNE4.png"));

            walkingNorth = ImageIO.read(new File("src/assets/playerassets/redhead/walkingN.png"));
            walkingNorth2 = ImageIO.read(new File("src/assets/playerassets/redhead/walkingN2.png"));
            walkingNorth3 = ImageIO.read(new File("src/assets/playerassets/redhead/walkingN3.png"));
            walkingNorth4 = ImageIO.read(new File("src/assets/playerassets/redhead/walkingN4.png"));

            walkingNorthwest = ImageIO.read(new File("src/assets/playerassets/redhead/walkingNW.png"));
            walkingNorthwest2 = ImageIO.read(new File("src/assets/playerassets/redhead/walkingNW2.png"));
            walkingNorthwest3 = ImageIO.read(new File("src/assets/playerassets/redhead/walkingNW3.png"));
            walkingNorthwest4 = ImageIO.read(new File("src/assets/playerassets/redhead/walkingNW4.png"));

            walkingEast = ImageIO.read(new File("src/assets/playerassets/redhead/walkingE.png"));
            walkingEast2 = ImageIO.read(new File("src/assets/playerassets/redhead/walkingE2.png"));
            walkingEast3 = ImageIO.read(new File("src/assets/playerassets/redhead/walkingE3.png"));
            walkingEast4 = ImageIO.read(new File("src/assets/playerassets/redhead/walkingE4.png"));

            walkingSoutheast = ImageIO.read(new File("src/assets/playerassets/redhead/walkingSE.png"));
            walkingSoutheast2 = ImageIO.read(new File("src/assets/playerassets/redhead/walkingSE2.png"));
            walkingSoutheast3 = ImageIO.read(new File("src/assets/playerassets/redhead/walkingSE3.png"));
            walkingSoutheast4 = ImageIO.read(new File("src/assets/playerassets/redhead/walkingSE4.png"));

            walkingSouth = ImageIO.read(new File("src/assets/playerassets/redhead/walkingS.png"));
            walkingSouth2 = ImageIO.read(new File("src/assets/playerassets/redhead/walkingS2.png"));
            walkingSouth3 = ImageIO.read(new File("src/assets/playerassets/redhead/walkingS3.png"));
            walkingSouth4 = ImageIO.read(new File("src/assets/playerassets/redhead/walkingS4.png"));

            walkingSouthwest = ImageIO.read(new File("src/assets/playerassets/redhead/walkingSW.png"));
            walkingSouthwest2 = ImageIO.read(new File("src/assets/playerassets/redhead/walkingSW2.png"));
            walkingSouthwest3 = ImageIO.read(new File("src/assets/playerassets/redhead/walkingSW3.png"));
            walkingSouthwest4 = ImageIO.read(new File("src/assets/playerassets/redhead/walkingSW4.png"));

            walkingWest = ImageIO.read(new File("src/assets/playerassets/redhead/walkingW.png"));
            walkingWest2 = ImageIO.read(new File("src/assets/playerassets/redhead/walkingW2.png"));
            walkingWest3 = ImageIO.read(new File("src/assets/playerassets/redhead/walkingW3.png"));
            walkingWest4 = ImageIO.read(new File("src/assets/playerassets/redhead/walkingW4.png"));

            error = ImageIO.read(new File("src/assets/error.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void getPlayerAttackImage() {
        try {
            attackNorth = ImageIO.read(new File("src/assets/playerassets/redhead/redheadAttack/attack_northeast.png"));
            attackNorth2 = ImageIO.read(new File("src/assets/playerassets/redhead/redheadAttack/attack_northeast2.png"));

            attackNortheast = ImageIO.read(new File("src/assets/playerassets/redhead/redheadAttack/attack_northeast.png"));
            attackNortheast2 = ImageIO.read(new File("src/assets/playerassets/redhead/redheadAttack/attack_northeast2.png"));

            attackNorthwest = ImageIO.read(new File("src/assets/playerassets/redhead/redheadAttack/attack_northwest.png"));
            attackNorthwest2 = ImageIO.read(new File("src/assets/playerassets/redhead/redheadAttack/attack_northwest2.png"));

            attackSouth = ImageIO.read(new File("src/assets/playerassets/redhead/redheadAttack/attack_southwest.png"));
            attackSouth2 = ImageIO.read(new File("src/assets/playerassets/redhead/redheadAttack/attack_southwest2.png"));

            attackSouthwest = ImageIO.read(new File("src/assets/playerassets/redhead/redheadAttack/attack_southwest.png"));
            attackSouthwest2 = ImageIO.read(new File("src/assets/playerassets/redhead/redheadAttack/attack_southwest2.png"));

            attackSoutheast = ImageIO.read(new File("src/assets/playerassets/redhead/redheadAttack/attack_southeast.png"));
            attackSoutheast2 = ImageIO.read(new File("src/assets/playerassets/redhead/redheadAttack/attack_southeast2.png"));

            attackEast = ImageIO.read(new File("src/assets/playerassets/redhead/redheadAttack/attack_southeast.png"));
            attackEast2 = ImageIO.read(new File("src/assets/playerassets/redhead/redheadAttack/attack_southeast2.png"));

            attackWest = ImageIO.read(new File("src/assets/playerassets/redhead/redheadAttack/attack_northwest.png"));
            attackWest2 = ImageIO.read(new File("src/assets/playerassets/redhead/redheadAttack/attack_northwest2.png"));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    
    public void update() {
   

        

        if (attacking == true) {
           attacking();
        } 
        if(keyH.upPressed && keyH.leftPressed) {
            direction = "Northwest";
        }
        else if(keyH.upPressed && keyH.rightPressed) {
            direction = "Northeast";
        }
        else if(keyH.upPressed) {
            direction = "North";
        }
        else if(keyH.downPressed && keyH.leftPressed) {
            direction = "Southwest";
        }
        else if(keyH.downPressed && keyH.rightPressed) {
            direction = "Southeast";
        }
        else if(keyH.downPressed) {
            direction = "South";
        }
        else if(keyH.leftPressed) {
            direction = "West";
        }
        else if(keyH.rightPressed) {
            direction = "East";
        }

        if(attacking == false) {
            movementCounter++;
        }

        // CHECK TILE COLLISION
        collisionOn = false;
        gp.cChecker.checkTile(this);

        // CHECK OBJECT COLLISION
        int objIndex = gp.cChecker.checkObject(this, true);
        pickUpObject(objIndex);

        // CHECK NPC COLLISION
        int npcIndex = gp.cChecker.checkEntity(this, gp.npc);
        interactNPC(npcIndex);

        // CHECK MONSTER COLLISION
        int monsterIndex = gp.cChecker.checkEntity(this, gp.monster);

        contactMonster(monsterIndex);

        // CHECK EVENT
        gp.eHandler.checkEvent();

        //if collision on is false and the player is pressing a key move a direction based on the directional string in the direction variable
        if (collisionOn == false && 
        (keyH.upPressed || keyH.downPressed ||
        keyH.leftPressed || keyH.rightPressed))
                {
                switch(direction) {
                    case "North": worldY -= speed; break;
                    case "South": worldY += speed; break;
                    case "West": worldX -= speed; break;
                    case "East": worldX += speed; break;
                    case "Northwest": worldX -= speed - (speed /4); worldY -= speed - (speed /4); break;
                    case "Northeast": worldX += speed - (speed /4); worldY -= speed - (speed /4); break;
                    case "Southwest": worldX -= speed - (speed /4); worldY += speed - (speed /4); break;
                    case "Southeast": worldX += speed - (speed /4); worldY += speed - (speed /4); break;
                }
        }

        if (movementCounter > 12) {
            if (movementNum == 1) {
                movementNum = 2;
            } else if (movementNum == 2) {
                movementNum = 3;
            } else if (movementNum == 3) {
                movementNum = 4;
            } else if (movementNum == 4) {
                movementNum = 1;
            }
            movementCounter = 0;

        }

        // invincible timing | THIS MUST BE OUTSIDE THE IF STATEMENTS
        if (invincible == true) {
            invincibleCounter++;
            if (invincibleCounter > 30) {
                invincible = false;
                invincibleCounter = 0;
            }
        }
    }

    public void attacking() {
        attackCounter++;

        if (attackCounter <= 5) {
            attackNum = 1;
        }
        if (attackCounter > 5 && attackCounter <= 25) {
            attackNum = 2;

            //SAVE THE CURRENT WORLDX WORLDY AND SOLID AREA
            int currentWorldX = worldX;
            int currentWorldY = worldY;
            int solidAreaWidth = solidArea.width;
            int solidAreaHeight = solidArea.height;

            //ADJUST PLAYERS WORLDX AND Y FOR ATTACK AREA
            switch(direction) {
                case "North": worldY -= attackArea.height; break;
                case "South": worldY += attackArea.height; break;
                case "West" : worldX -= attackArea.width; break;
                case "East" : worldX += attackArea.width; break;
                case "Northwest":
                worldY -= attackArea.height;
                worldX -= attackArea.width;
                break;
                case "Northeast":
                worldY -= attackArea.height;
                worldX += attackArea.width;
                break;
                case "Southwest":
                worldY += attackArea.height;
                worldX -= attackArea.width;
                break;
                case "Southeast":
                worldY += attackArea.height;
                worldX += attackArea.width;
                break;
            }

            //attack area becomes solid area
            solidArea.width = attackArea.width;
            solidArea.height = attackArea.height;

            //check monster collision with updated worldX worldY and solidArea
            int monsterIndex = gp.cChecker.checkEntity(this, gp.monster);

            damageMonster(monsterIndex);

            //restore original solidArea, and WorldX / Y
            worldX = currentWorldX;
            worldY = currentWorldY;

            solidArea.width = solidAreaWidth;
            solidArea.height = solidAreaHeight;

        }
        if (attackCounter > 25) {
            attacking = false;
            attackNum = 1;
            attackCounter = 0;

        }
    }
    public void damageMonster(int i) {

        if(i != 999) {

            if(gp.monster[i].invincible == false) {

                int damage = attack - gp.monster[i].defense;
                if(damage < 0) {
                damage = 0;
                }
                gp.monster[i].life -= damage;
                gp.ui.addMessage(damage + " damage!");

                gp.monster[i].invincible = true;
                gp.monster[i].damageReaction();

                if(gp.monster[i].life <= 0) {
                    gp.monster[i].dying = true;
                    gp.ui.addMessage("Killed the " + gp.monster[i].name + "!");
                    gp.ui.addMessage("Exp + " + gp.monster[i].exp);
                    exp += gp.monster[i].exp;
                    checkLevelUp();
                }
            }
        }
        else {
            
        }
    }

    public void contactMonster(int i) {

        if (i != 999) {
            

            if (invincible == false && gp.monster[i].alive == true && gp.monster[i].dying == false) {
                
                int damage = gp.monster[i].attack - defense;
                if(damage < 0) {
                damage = 0;
            }
                life -= damage;
                invincible = true;
            }
        }
    }

    public void pickUpObject(int i) {
        if (i != 999) {

        }
    }

    public void interactNPC(int i) {
        if (i != 999) {
            if (gp.keyH.ePressed == true) {
                gp.gameState = gp.dialogueState;
                gp.npc[i].speak();
            }

        }

    }
    public void checkLevelUp() {
        while(exp >= nextLevelExp) {
            level++;
            lastLevelExp = nextLevelExp;
            System.out.println(lastLevelExp + " last level");
            exp -= (int) nextLevelExp;
            nextLevelExp = lastLevelExp * 1.2;
            DecimalFormat oHundredsPlace = new DecimalFormat("#.00");
            fixedNextLevelExp = oHundredsPlace.format(nextLevelExp);
            
            maxLife += 2;
            life = maxLife;
            strength++;
            dexterity++;
            attack = getAttack();
            defense = getDefense();

            gp.gameState = gp.dialogueState;
            gp.ui.currentDialogue = "You are level " + level + " now!\n You feel stronger";
        }
    }

    public void draw(Graphics2D g2) {

        BufferedImage image = null;
        int tempScreenX = screenX;
        int tempScreenY = screenY;

        if ((keyH.upPressed || keyH.downPressed || keyH.leftPressed || keyH.rightPressed) && attacking == false) {
            switch (direction) {
                case "North":
                        if (movementNum == 1) {
                            image = walkingNorth;
                        }
                        if (movementNum == 2) {
                            image = walkingNorth2;
                        }
                        if (movementNum == 3) {
                            image = walkingNorth3;
                        }
                        if (movementNum == 4) {
                            image = walkingNorth4;
                        }
                    break;
                case "Northeast":
                    if (attacking == false) {
                        if (movementNum == 1) {
                            image = walkingNortheast;
                        }
                        if (movementNum == 2) {
                            image = walkingNortheast2;
                        }
                        if (movementNum == 3) {
                            image = walkingNortheast3;
                        }
                        if (movementNum == 4) {
                            image = walkingNortheast4;
                        }
                    }
                    break;
                case "Northwest":
                    if (attacking == false) {
                        if (movementNum == 1) {
                            image = walkingNorthwest;
                        }
                        if (movementNum == 2) {
                            image = walkingNorthwest2;
                        }
                        if (movementNum == 3) {
                            image = walkingNorthwest3;
                        }
                        if (movementNum == 4) {
                            image = walkingNorthwest4;
                        }
                    }
                    break;
                case "South":
                    if (attacking == false) {
                        if (movementNum == 1) {
                            image = walkingSouth;
                        }
                        if (movementNum == 2) {
                            image = walkingSouth2;
                        }
                        if (movementNum == 3) {
                            image = walkingSouth3;
                        }
                        if (movementNum == 4) {
                            image = walkingSouth4;
                        }
                    }
                    break;
                case "Southeast":
                    if (attacking == false) {
                        if (movementNum == 1) {
                            image = walkingSoutheast;
                        }
                        if (movementNum == 2) {
                            image = walkingSoutheast2;
                        }
                        if (movementNum == 3) {
                            image = walkingSoutheast3;
                        }
                        if (movementNum == 4) {
                            image = walkingSoutheast4;
                        }
                    }
                    break;
                case "Southwest":
                    if (attacking == false) {
                        if (movementNum == 1) {
                            image = walkingSouthwest;
                        }
                        if (movementNum == 2) {
                            image = walkingSouthwest2;
                        }
                        if (movementNum == 3) {
                            image = walkingSouthwest3;
                        }
                        if (movementNum == 4) {
                            image = walkingSouthwest4;
                        }
                    }
                    break;
                case "West":
                    if (attacking == false) {
                        if (movementNum == 1) {
                            image = walkingWest;
                        }
                        if (movementNum == 2) {
                            image = walkingWest2;
                        }
                        if (movementNum == 3) {
                            image = walkingWest3;
                        }
                        if (movementNum == 4) {
                            image = walkingWest4;
                        }
                    }
                    break;
                case "East":
                    if (attacking == false) {
                        if (movementNum == 1) {
                            image = walkingEast;
                        }
                        if (movementNum == 2) {
                            image = walkingEast2;
                        }
                        if (movementNum == 3) {
                            image = walkingEast3;
                        }
                        if (movementNum == 4) {
                            image = walkingEast4;
                        }
                    }
                    break;
            }
        }
        else if (attacking == true) {
            switch (direction) {
                case "North":
                        if (attackNum == 1) {
                            image = attackNorth;
                        }
                        if (attackNum == 2) {
                            image = attackNorth2;
                        }
                    break;
                case "Northeast":
                        if (attackNum == 1) {
                            image = attackNortheast;
                        }
                        if (attackNum == 2) {
                            image = attackNortheast2;
                        }
                    break;
                case "Northwest":
                        if (attackNum == 1) {
                            image = attackNorthwest;
                        }
                        if (attackNum == 2) {
                            image = attackNorthwest2;
                        }
                    break;
                case "South":
                        if (attackNum == 1) {
                            image = attackSouth;
                        }
                        if (attackNum == 2) {
                            image = attackSouth2;
                        }
                    break;
                case "Southeast":
                        if (attackNum == 1) {
                            image = attackSoutheast;
                        }
                        if (attackNum == 2) {
                            image = attackSoutheast2;
                        }
                    break;
                case "Southwest":
                        if (attackNum == 1) {
                            image = attackSouthwest;
                        }
                        if (attackNum == 2) {
                            image = attackSouthwest2;
                        }
                    break;
                case "West":
                        if (attackNum == 1) {
                            image = attackWest;
                        }
                        if (attackNum == 2) {
                            image = attackWest2;
                        }
                    break;
                case "East":
                        if (attackNum == 1) {
                            image = attackEast;
                        }
                        if (attackNum == 2) {
                            image = attackEast2;
                        }
                    break;
            }
        }           
        else if (!(keyH.upPressed || keyH.downPressed || keyH.leftPressed || keyH.rightPressed) && attacking == false) {
                switch (direction) {
                    case "Northwest":
                        image = facingNorthwest;
                        break;
                    case "North":
                        image = facingNorth;
                        break;
                    case "Northeast":
                        image = facingNortheast;
                        break;
                    case "East":
                        image = facingEast;
                        break;
                    case "Southeast":
                        image = facingSoutheast;
                        break;
                    case "South":
                        image = facingSouth;
                        break;
                    case "Southwest":
                        image = facingSouthwest;
                        break;
                    case "West":
                        image = facingWest;

                }
            }
        
        
            g2.drawImage(image, screenX, screenY, gp.tileSize + (gp.tileSize), gp.tileSize + (gp.tileSize), null);
            
        
        if (keyH.debug == true) {
            // AttackArea
		    tempScreenX = screenX + solidArea.x;
		    tempScreenY = screenY + solidArea.y;		
		    switch(direction) {
            case "Northwest": tempScreenY -= attackArea.height; tempScreenX -= attackArea.width; break;
		    case "North": tempScreenY -= attackArea.height; break;
            case "Northeast": tempScreenY -= attackArea.height; tempScreenX += attackArea.width; break;
		    case "South": tempScreenY += attackArea.height; break; 
            case "Southwest": tempScreenY += attackArea.height; tempScreenX -= attackArea.width; break;
		    case "West": tempScreenX -= attackArea.width; break;
            case "Southeast": tempScreenY += attackArea.height; tempScreenX += attackArea.width; break;
		    case "East": tempScreenX += attackArea.width; break;
		}				
            g2.setColor(Color.red);
            g2.setStroke(new BasicStroke(1));
            g2.drawRect(screenX + solidArea.x, screenY + solidArea.y, solidArea.width, solidArea.height);
            g2.drawRect(tempScreenX, tempScreenY, attackArea.width, attackArea.height);

        }

    }

}