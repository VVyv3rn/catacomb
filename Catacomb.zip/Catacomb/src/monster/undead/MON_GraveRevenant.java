package monster.undead;

import java.io.File;
import java.io.IOException;


import javax.imageio.ImageIO;

import entity.Entity;
import main.GamePanel;

public class MON_GraveRevenant extends Entity {

        public MON_GraveRevenant(GamePanel gp, boolean aiStatus) {
                super(gp);

                type = 2;
                name = "Grave Revenant";
                speed = 1;
                maxLife = 4;
                life = maxLife;
                attack = 1 + (gp.player.level * 2 / (gp.player.level));
                defense = 0;
                exp = 5;
                hasAI = aiStatus;
                solidArea.x = (gp.player.solidArea.x / 2) - gp.tileSize / 4;
                solidArea.y = (gp.tileSize / 2);
                solidArea.width = gp.player.solidArea.width;
                solidArea.height = gp.player.solidArea.height;

                solidAreaDefaultX = solidArea.x;
                solidAreaDefaultY = solidArea.y;

                getImage();

        }

        public void getImage() {

                try {

                        // assign values to the walking states

                        walkingNortheast = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev1.png"));
                        walkingNortheast2 = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev2.png"));
                        walkingNortheast3 = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev3.png"));
                        walkingNortheast4 = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev4.png"));

                        walkingNorth = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev1.png"));
                        walkingNorth2 = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev2.png"));
                        walkingNorth3 = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev3.png"));
                        walkingNorth4 = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev4.png"));

                        walkingNorthwest = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev1.png"));
                        walkingNorthwest2 = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev2.png"));
                        walkingNorthwest3 = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev3.png"));
                        walkingNorthwest4 = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev4.png"));

                        walkingEast = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev1.png"));
                        walkingEast2 = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev2.png"));
                        walkingEast3 = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev3.png"));
                        walkingEast4 = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev4.png"));

                        walkingSoutheast = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev1.png"));
                        walkingSoutheast2 = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev2.png"));
                        walkingSoutheast3 = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev3.png"));
                        walkingSoutheast4 = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev4.png"));

                        walkingSouth = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev1.png"));
                        walkingSouth2 = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev2.png"));
                        walkingSouth3 = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev3.png"));
                        walkingSouth4 = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev4.png"));

                        walkingSouthwest = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev1.png"));
                        walkingSouthwest2 = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev2.png"));
                        walkingSouthwest3 = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev3.png"));
                        walkingSouthwest4 = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev4.png"));

                        walkingWest = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev1.png"));
                        walkingWest2 = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev2.png"));
                        walkingWest3 = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev3.png"));
                        walkingWest4 = ImageIO
                                        .read(new File("src/assets/entityassets/undeadassets/grave_revenant/graverev4.png"));
                } catch (IOException e) {
                        e.printStackTrace();
                }
        }
}
