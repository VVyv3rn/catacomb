package monster.undead;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import entity.Entity;
import main.GamePanel;

public class MON_DecrepitBones extends Entity{
    
    public MON_DecrepitBones(GamePanel gp, boolean aiStatus) {
        super(gp);

        type = 2;
        name = "Decrepit Bones";
        speed = 1;
        maxLife = 8;
        life = maxLife;
        attack = 1 + (gp.player.level * 2 / (gp.player.level));
        defense = 0;
        exp = 5;
        hasAI = aiStatus;

        solidArea.x = (gp.player.solidArea.x / 2) - gp.tileSize / 4;
        solidArea.y = (gp.tileSize / 2);
        solidArea.width = gp.player.solidArea.width;
        solidArea.height = gp.player.solidArea.height;

        solidAreaDefaultX = solidArea.x;
        solidAreaDefaultY = solidArea.y;

        getImage();

    }

    public void getImage() {

        try {
            walkingNorth = ImageIO
                    .read(new File("src/assets/entityassets/undeadassets/decrepit_bones/decrepitbones0.png"));
            walkingNorth2 = ImageIO
                    .read(new File("src/assets/entityassets/undeadassets/decrepit_bones/decrepitbones1.png"));
            walkingNorth3 = ImageIO
                    .read(new File("src/assets/entityassets/undeadassets/decrepit_bones/decrepitbones2.png"));
            walkingNorth4 = ImageIO
                    .read(new File("src/assets/entityassets/undeadassets/decrepit_bones/decrepitbones3.png"));

            walkingNortheast = walkingNorth;
            walkingNortheast2 = walkingNorth2;
            walkingNortheast3 = walkingNorth3;
            walkingNortheast4 = walkingNorth4;

            walkingNorthwest = walkingNorth;
            walkingNorthwest2 = walkingNorth2;
            walkingNorthwest3 = walkingNorth3;
            walkingNorthwest4 = walkingNorth4;

            walkingWest = walkingNorth;
            walkingWest2 = walkingNorth2;
            walkingWest3 = walkingNorth3;
            walkingWest4 = walkingNorth4;

            walkingEast = walkingNorth;
            walkingEast2 = walkingNorth2;
            walkingEast3 = walkingNorth3;
            walkingEast4 = walkingNorth4;

            walkingSouth = walkingNorth;
            walkingSouth2 = walkingNorth2;
            walkingSouth3 = walkingNorth3;
            walkingSouth4 = walkingNorth4;

            walkingSoutheast = walkingNorth;
            walkingSoutheast2 = walkingNorth2;
            walkingSoutheast3 = walkingNorth3;
            walkingSoutheast4 = walkingNorth4;

            walkingSouthwest = walkingNorth;
            walkingSouthwest2 = walkingNorth2;
            walkingSouthwest3 = walkingNorth3;
            walkingSouthwest4 = walkingNorth4;

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}