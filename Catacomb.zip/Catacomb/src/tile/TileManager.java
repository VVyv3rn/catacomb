package tile;

import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.imageio.ImageIO;

import main.GamePanel;

public class TileManager {
    
    GamePanel gp;
    public Tile[] tile;
    public int mapTileNum[][];

    public TileManager(GamePanel gp) {
        this.gp = gp;
        
        tile = new Tile[200];
        mapTileNum = new int[gp.maxWorldCol][gp.maxWorldRow];
        
        getTileImage();
        loadMap(new String("src/assets/mapassets/maps/empty_map.txt"));
    }

    public void getTileImage() {

        try {
            
            //MAIN ASSET FILE
            tile[0] = new Tile();
            tile[0].image = ImageIO.read(new File("src/assets/air.png"));


            //WALL ASSETS

            tile[1] = new Tile();
            tile[1].image = ImageIO.read(new File("src/assets/mapassets/wall/door/door_closed.png"));
            tile[1].collision = true;

            tile[2] = new Tile();
            tile[2].image = ImageIO.read(new File("src/assets/mapassets/wall/door/door_left.png"));
            tile[2].collision = true;

            tile[3] = new Tile();
            tile[3].image = ImageIO.read(new File("src/assets/mapassets/wall/door/door_open.png"));
            tile[3].collision = true;

            tile[4] = new Tile();
            tile[4].image = ImageIO.read(new File("src/assets/mapassets/wall/door/door_right.png"));
            tile[4].collision = true;

            tile[5] = new Tile();
            tile[5].image = ImageIO.read(new File("src/assets/mapassets/wall/walldecor/flag/wall_flag_blue.png"));
            tile[5].collision = true;

            tile[6] = new Tile();
            tile[6].image = ImageIO.read(new File("src/assets/mapassets/wall/walldecor/flag/wall_flag_green.png"));
            tile[6].collision = true;

            tile[7] = new Tile();
            tile[7].image = ImageIO.read(new File("src/assets/mapassets/wall/walldecor/flag/wall_flag_red.png"));
            tile[7].collision = true;

            tile[8] = new Tile();
            tile[8].image = ImageIO.read(new File("src/assets/mapassets//wall/walldecor/flag/wall_flag_yellow.png"));
            tile[8].collision = true;

            tile[9] = new Tile();
            tile[9].image = ImageIO.read(new File("src/assets/mapassets/wall/walldecor/outline/Wall_outline_1.png"));
            tile[9].collision = true;

            tile[10] = new Tile();
            tile[10].image = ImageIO.read(new File("src/assets/mapassets/wall/walldecor/outline/Wall_outline_2.png"));
            tile[10].collision = true;

            tile[11] = new Tile();
            tile[11].image = ImageIO.read(new File("src/assets/mapassets/wall/walldecor/outline/Wall_outline_left.png"));
            tile[11].collision = true;

            tile[12] = new Tile();
            tile[12].image = ImageIO.read(new File("src/assets/mapassets/wall/walldecor/outline/Wall_outline_right.png"));
            tile[12].collision = true;

            tile[13] = new Tile();
            tile[13].image = ImageIO.read(new File("src/assets/mapassets/wall/walldecor/pipe/wall_drain_gate.png"));
            tile[13].collision = true;

            tile[14] = new Tile();
            tile[14].image = ImageIO.read(new File("src/assets/mapassets/wall/walldecor/pipe/wall_gratings.png"));
            tile[14].collision = true;

            tile[15] = new Tile();
            tile[15].image = ImageIO.read(new File("src/assets/mapassets/wall/walldecor/pipe/wall_pipe_1.png"));
            tile[15].collision = true;

            tile[16] = new Tile();
            tile[16].image = ImageIO.read(new File("src/assets/mapassets/wall/walldecor/pipe/wall_pipe_2.png"));
            tile[16].collision = true;

            tile[17] = new Tile();
            tile[17].image = ImageIO.read(new File("src/assets/mapassets/wall/walldecor/pipe/wall_pipe_small.png"));
            tile[17].collision = true;

            tile[18] = new Tile();
            tile[18].image = ImageIO.read(new File("src/assets/mapassets/wall/walldecor/wallfluids/wall_gargoyle_blue_1.png"));
            tile[18].collision = true;

            tile[19] = new Tile();
            tile[19].image = ImageIO.read(new File("src/assets/mapassets/wall/walldecor/wallfluids/wall_gargoyle_blue_2.png"));
            tile[19].collision = true;

            tile[20] = new Tile();
            tile[20].image = ImageIO.read(new File("src/assets/mapassets/wall/walldecor/wallfluids/wall_gargoyle_green_1.png"));
            tile[20].collision = true;

            tile[21] = new Tile();
            tile[21].image = ImageIO.read(new File("src/assets/mapassets/wall/walldecor/wallfluids/wall_gargoyle_green_2.png"));
            tile[21].collision = true;

            tile[22] = new Tile();
            tile[22].image = ImageIO.read(new File("src/assets/mapassets/wall/walldecor/wallfluids/wall_gargoyle_mid_blue_left.png"));
            tile[22].collision = true;

            tile[23] = new Tile();
            tile[23].image = ImageIO.read(new File("src/assets/mapassets/wall/walldecor/wallfluids/wall_gargoyle_mid_blue_right.png"));
            tile[23].collision = true;

            tile[24] = new Tile();
            tile[24].image = ImageIO.read(new File("src/assets/mapassets/wall/walldecor/wallfluids/wall_gargoyle_mid_green_left.png"));
            tile[24].collision = true;

            tile[25] = new Tile();
            tile[25].image = ImageIO.read(new File("src/assets/mapassets/wall/walldecor/wallfluids/wall_gargoyle_mid_green_right.png"));
            tile[25].collision = true;

            tile[26] = new Tile();
            tile[26].image = ImageIO.read(new File("src/assets/mapassets/wall/walldecor/wallfluids/wall_gargoyle_mid_red_left.png"));
            tile[26].collision = true;

            tile[27] = new Tile();
            tile[27].image = ImageIO.read(new File("src/assets/mapassets/wall/walldecor/wallfluids/wall_gargoyle_mid_red_right.png"));
            tile[27].collision = true;

            tile[28] = new Tile();
            tile[28].image = ImageIO.read(new File("src/assets/mapassets/wall/walldecor/wallfluids/wall_gargoyle_red_1.png"));
            tile[28].collision = true;

            tile[29] = new Tile();
            tile[29].image = ImageIO.read(new File("src/assets/mapassets/wall/walldecor/wallfluids/wall_gargoyle_red_1.png"));
            tile[29].collision = true;

            tile[30] = new Tile();
            tile[30].image = ImageIO.read(new File("src/assets/mapassets/wall/walldecor/wallfluids/wall_goo.png"));
            tile[30].collision = true;

            tile[31] = new Tile();
            tile[31].image = ImageIO.read(new File("src/assets/mapassets/wall/wallextras/column/column.png"));
            tile[31].collision = true;

            tile[32] = new Tile();
            tile[32].image = ImageIO.read(new File("src/assets/mapassets/wall/wallextras/column/column_wall.png"));
            tile[32].collision = true;

            tile[33] = new Tile();
            tile[33].image = ImageIO.read(new File("src/assets/mapassets/wall/wallextras/inner/Wall_inner_e.png"));
            tile[33].collision = true;

            tile[151] = new Tile();
            tile[151].image = ImageIO.read(new File("src/assets/mapassets/wall/wallextras/inner/Wall_inner_ne.png"));
            tile[151].collision = true;

            tile[150] = new Tile();
            tile[150].image = ImageIO.read(new File("src/assets/mapassets/wall/wallextras/inner/Wall_inner_nw.png"));
            tile[150].collision = true;

            tile[34] = new Tile();
            tile[34].image = ImageIO.read(new File("src/assets/mapassets/wall/wallextras/inner/Wall_inner_se.png"));
            tile[34].collision = true;

            tile[35] = new Tile();
            tile[35].image = ImageIO.read(new File("src/assets/mapassets/wall/wallextras/inner/Wall_inner_sw.png"));
            tile[35].collision = true;

            tile[36] = new Tile();
            tile[36].image = ImageIO.read(new File("src/assets/mapassets/wall/wallextras/inner/Wall_inner_w.png"));
            tile[36].collision = true;

            tile[37] = new Tile();
            tile[37].image = ImageIO.read(new File("src/assets/mapassets/wall/wallextras/outer/Wall_outer_e.png"));
            tile[37].collision = true;

            tile[38] = new Tile();
            tile[38].image = ImageIO.read(new File("src/assets/mapassets/wall/wallextras/outer/Wall_outer_e2.png"));
            tile[38].collision = true;

            tile[39] = new Tile();
            tile[39].image = ImageIO.read(new File("src/assets/mapassets/wall/wallextras/outer/Wall_outer_n.png"));
            tile[39].collision = true;

            tile[40] = new Tile();
            tile[40].image = ImageIO.read(new File("src/assets/mapassets/wall/wallextras/outer/Wall_outer_ne.png"));
            tile[40].collision = true;

            tile[41] = new Tile();
            tile[41].image = ImageIO.read(new File("src/assets/mapassets/wall/wallextras/outer/Wall_outer_nw.png"));
            tile[41].collision = true;

            tile[42] = new Tile();
            tile[42].image = ImageIO.read(new File("src/assets/mapassets/wall/wallextras/outer/Wall_outer_se.png"));
            tile[42].collision = true;

            tile[43] = new Tile();
            tile[43].image = ImageIO.read(new File("src/assets/mapassets/wall/wallextras/outer/Wall_outer_sw.png"));
            tile[43].collision = true;

            tile[44] = new Tile();
            tile[44].image = ImageIO.read(new File("src/assets/mapassets/wall/wallextras/outer/Wall_outer_w.png"));
            tile[44].collision = true;

            tile[45] = new Tile();
            tile[45].image = ImageIO.read(new File("src/assets/mapassets/wall/wallextras/outer/Wall_outer_w2.png"));
            tile[45].collision = true;

            tile[46] = new Tile();
            tile[46].image = ImageIO.read(new File("src/assets/mapassets/wall/wallextras/wall_top_center.png"));
            tile[46].collision = true;

            tile[47] = new Tile();
            tile[47].image = ImageIO.read(new File("src/assets/mapassets/wall/wallextras/wall_top_left.png"));
            tile[47].collision = true;

            tile[48] = new Tile();
            tile[48].image = ImageIO.read(new File("src/assets/mapassets/wall/wallextras/wall_top_right.png"));
            tile[48].collision = true;

            tile[49] = new Tile();
            tile[49].image = ImageIO.read(new File("src/assets/mapassets/wall/wall_center.png"));
            tile[49].collision = true;

            tile[50] = new Tile();
            tile[50].image = ImageIO.read(new File("src/assets/mapassets/wall/Wall_front.png"));
            tile[50].collision = true;

            tile[51] = new Tile();
            tile[51].image = ImageIO.read(new File("src/assets/mapassets/wall/Wall_front_left.png"));
            tile[51].collision = true;

            tile[52] = new Tile();
            tile[52].image = ImageIO.read(new File("src/assets/mapassets/wall/Wall_front_right.png"));
            tile[52].collision = true;

            tile[53] = new Tile();
            tile[53].image = ImageIO.read(new File("src/assets/mapassets/wall/wall_left.png"));
            tile[53].collision = true;

            tile[54] = new Tile();
            tile[54].image = ImageIO.read(new File("src/assets/mapassets/wall/wall_missing_brick_1.png"));
            tile[54].collision = true;

            tile[55] = new Tile();
            tile[55].image = ImageIO.read(new File("src/assets/mapassets/wall/wall_missing_brick_2.png"));
            tile[55].collision = true;

            tile[56] = new Tile();
            tile[56].image = ImageIO.read(new File("src/assets/mapassets/wall/wall_right.png"));
            tile[56].collision = true;

            //ADD FLOOR ASSETS TO THE ARRAY

            tile[57] = new Tile();
            tile[57].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/gargoyle/floor_gargoyle_blue_basin.png"));
            tile[57].collision = false;

            tile[58] = new Tile();
            tile[58].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/gargoyle/floor_gargoyle_blue_puddle.png"));
            tile[58].collision = false;

            tile[59] = new Tile();
            tile[59].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/gargoyle/floor_gargoyle_green_basin.png"));
            tile[59].collision = false;

            tile[60] = new Tile();
            tile[60].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/gargoyle/floor_gargoyle_green_puddle.png"));
            tile[60].collision = false;

            tile[61] = new Tile();
            tile[61].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/gargoyle/floor_gargoyle_mid_blue_left.png"));
            tile[61].collision = false;

            tile[62] = new Tile();
            tile[62].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/gargoyle/floor_gargoyle_mid_blue_right.png"));
            tile[62].collision = false;

            tile[63] = new Tile();
            tile[63].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/gargoyle/floor_gargoyle_mid_green_left.png"));
            tile[63].collision = false;

            tile[64] = new Tile();
            tile[64].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/gargoyle/floor_gargoyle_mid_green_right.png"));
            tile[64].collision = false;

            tile[65] = new Tile();
            tile[65].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/gargoyle/floor_gargoyle_mid_red_left.png"));
            tile[65].collision = false;

            tile[66] = new Tile();
            tile[66].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/gargoyle/floor_gargoyle_mid_red_right.png"));
            tile[66].collision = false;

            tile[67] = new Tile();
            tile[67].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/gargoyle/floor_gargoyle_red_basin.png"));
            tile[67].collision = false;
            
            tile[68] = new Tile();
            tile[68].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/gargoyle/floor_gargoyle_red_puddle.png"));
            tile[68].collision = false;

            tile[69] = new Tile();
            tile[69].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/floor_mud_e.png"));
            tile[69].collision = false;

            tile[70] = new Tile();
            tile[70].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/floor_mud_mid_1.png"));
            tile[70].collision = false;

            tile[71] = new Tile();
            tile[71].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/floor_mud_mid_2.png"));
            tile[71].collision = false;

            tile[72] = new Tile();
            tile[72].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/floor_mud_n_1.png"));
            tile[72].collision = false;

            tile[73] = new Tile();
            tile[73].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/floor_mud_n_2.png"));
            tile[73].collision = false;

            tile[74] = new Tile();
            tile[74].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/floor_mud_ne.png"));
            tile[74].collision = false;

            tile[75] = new Tile();
            tile[75].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/floor_mud_nw.png"));
            tile[75].collision = false;

            tile[76] = new Tile();
            tile[76].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/floor_mud_s_1.png"));
            tile[76].collision = false;

            tile[77] = new Tile();
            tile[77].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/floor_mud_s_2.png"));
            tile[77].collision = false;
            
            tile[78] = new Tile();
            tile[78].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/floor_mud_se.png"));
            tile[78].collision = false;

            tile[79] = new Tile();
            tile[79].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/floor_mud_sw.png"));
            tile[79].collision = false;

            tile[80] = new Tile();
            tile[80].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/floor_mud_w.png"));
            tile[80].collision = false;

            tile[81] = new Tile();
            tile[81].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/floor_stain_1.png"));
            tile[81].collision = false;

            tile[82] = new Tile();
            tile[82].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/floor_stain_2.png"));
            tile[82].collision = false;

            tile[83] = new Tile();
            tile[83].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/floor_stain_3.png"));
            tile[83].collision = false;

            tile[84] = new Tile();
            tile[84].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/floor_stain_e.png"));
            tile[84].collision = false;

            tile[85] = new Tile();
            tile[85].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/floor_stain_goo.png"));
            tile[85].collision = false;

            tile[86] = new Tile();
            tile[86].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/Floor_stain_n.png"));
            tile[86].collision = false;

            tile[87] = new Tile();
            tile[87].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/Floor_stain_ne.png"));
            tile[87].collision = false;

            tile[88] = new Tile();
            tile[88].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/Floor_stain_nw.png"));
            tile[88].collision = false;

            tile[89] = new Tile();
            tile[89].image = ImageIO.read(new File("src/assets/mapassets/floor/floordecor/Floor_stain_w.png"));
            tile[89].collision = false;

            tile[90] = new Tile();
            tile[90].image = ImageIO.read(new File("src/assets/mapassets/floor/floorextras/Edge_bricks.png"));
            tile[90].collision = false;

            tile[91] = new Tile();
            tile[91].image = ImageIO.read(new File("src/assets/mapassets/floor/floorextras/Edge_e.png"));
            tile[91].collision = false;

            tile[92] = new Tile();
            tile[92].image = ImageIO.read(new File("src/assets/mapassets/floor/floorextras/Edge_ne.png"));
            tile[92].collision = false;

            tile[93] = new Tile();
            tile[93].image = ImageIO.read(new File("src/assets/mapassets/floor/floorextras/Edge_ns.png"));
            tile[93].collision = false;

            tile[94] = new Tile();
            tile[94].image = ImageIO.read(new File("src/assets/mapassets/floor/floorextras/Edge_nse.png"));
            tile[94].collision = false;

            tile[95] = new Tile();
            tile[95].image = ImageIO.read(new File("src/assets/mapassets/floor/floorextras/Edge_nsw.png"));
            tile[95].collision = false;

            tile[96] = new Tile();
            tile[96].image = ImageIO.read(new File("src/assets/mapassets/floor/floorextras/Edge_nw.png"));
            tile[96].collision = false;

            tile[97] = new Tile();
            tile[97].image = ImageIO.read(new File("src/assets/mapassets/floor/floorextras/Edge_nwe.png"));
            tile[97].collision = false;

            tile[98] = new Tile();
            tile[98].image = ImageIO.read(new File("src/assets/mapassets/floor/floorextras/Edge_s.png"));
            tile[98].collision = false;

            tile[100] = new Tile();
            tile[100].image = ImageIO.read(new File("src/assets/mapassets/floor/floorextras/Edge_se.png"));
            tile[100].collision = false;

            tile[99] = new Tile();
            tile[99].image = ImageIO.read(new File("src/assets/mapassets/floor/floorextras/Edge_single.png"));
            tile[99].collision = false;

            tile[101] = new Tile();
            tile[101].image = ImageIO.read(new File("src/assets/mapassets/floor/floorextras/Edge_single_crack.png"));
            tile[101].collision = false;

            tile[102] = new Tile();
            tile[102].image = ImageIO.read(new File("src/assets/mapassets/floor/floorextras/Edge_sw.png"));
            tile[102].collision = false;

            tile[103] = new Tile();
            tile[103].image = ImageIO.read(new File("src/assets/mapassets/floor/floorextras/Edge_swe.png"));
            tile[103].collision = false;

            tile[104] = new Tile();
            tile[104].image = ImageIO.read(new File("src/assets/mapassets/floor/floorextras/Edge_w.png"));
            tile[104].collision = false;

            tile[105] = new Tile();
            tile[105].image = ImageIO.read(new File("src/assets/mapassets/floor/floorextras/Edge_we.png"));
            tile[105].collision = false;

            tile[106] = new Tile();
            tile[106].image = ImageIO.read(new File("src/assets/mapassets/floor/floorextras/floor_edge_1.png"));
            tile[106].collision = false;

            tile[107] = new Tile();
            tile[107].image = ImageIO.read(new File("src/assets/mapassets/floor/floorextras/floor_edge_2.png"));
            tile[107].collision = false;

            tile[108] = new Tile();
            tile[108].image = ImageIO.read(new File("src/assets/mapassets/floor/floorextras/floor_edge_3.png"));
            tile[108].collision = false;

            tile[109] = new Tile();
            tile[109].image = ImageIO.read(new File("src/assets/mapassets/floor/floorextras/floor_light.png"));
            tile[109].collision = false;

            tile[110] = new Tile();
            tile[110].image = ImageIO.read(new File("src/assets/mapassets/floor/pit/Pit_e.png"));
            tile[110].collision = true;
            
            tile[111] = new Tile();
            tile[111].image = ImageIO.read(new File("src/assets/mapassets/floor/pit/Pit_n.png"));
            tile[111].collision = true;
            
            tile[112] = new Tile();
            tile[112].image = ImageIO.read(new File("src/assets/mapassets/floor/pit/Pit_ne.png"));
            tile[112].collision = true;

            tile[113] = new Tile();
            tile[113].image = ImageIO.read(new File("src/assets/mapassets/floor/pit/Pit_nw.png"));
            tile[113].collision = true;

            tile[114] = new Tile();
            tile[114].image = ImageIO.read(new File("src/assets/mapassets/floor/pit/Pit_s.png"));
            tile[114].collision = true;

            tile[115] = new Tile();
            tile[115].image = ImageIO.read(new File("src/assets/mapassets/floor/pit/Pit_se.png"));
            tile[115].collision = true;

            tile[116] = new Tile();
            tile[116].image = ImageIO.read(new File("src/assets/mapassets/floor/pit/Pit_sw.png"));
            tile[116].collision = true;

            tile[117] = new Tile();
            tile[117].image = ImageIO.read(new File("src/assets/mapassets/floor/pit/Pit_w.png"));
            tile[117].collision = true;
            

            tile[118] = new Tile();
            tile[118].image = ImageIO.read(new File("src/assets/mapassets/floor/stair/stairs_bottom.png"));
            tile[118].collision = false;
            
            tile[119] = new Tile();
            tile[119].image = ImageIO.read(new File("src/assets/mapassets/floor/stair/stairs_mid.png"));
            tile[119].collision = false;

            tile[120] = new Tile();
            tile[120].image = ImageIO.read(new File("src/assets/mapassets/floor/stair/stairs_top.png"));
            tile[120].collision = false;

            tile[121] = new Tile();
            tile[121].image = ImageIO.read(new File("src/assets/mapassets/misc/chests/chest_closed.png"));
            tile[121].collision = true;

            tile[122] = new Tile();
            tile[122].image = ImageIO.read(new File("src/assets/mapassets/misc/chests/chest_golden_closed.png"));
            tile[122].collision = true;

            tile[123] = new Tile();
            tile[123].image = ImageIO.read(new File("src/assets/mapassets/misc/chests/chest_golden_open_empty.png"));
            tile[123].collision = true;

            tile[124] = new Tile();
            tile[124].image = ImageIO.read(new File("src/assets/mapassets/misc/chests/chest_golden_open_full.png"));
            tile[124].collision = true;

            tile[125] = new Tile();
            tile[125].image = ImageIO.read(new File("src/assets/mapassets/misc/chests/chest_open_empty.png"));
            tile[125].collision = true;

            tile[126] = new Tile();
            tile[126].image = ImageIO.read(new File("src/assets/mapassets/misc/chests/chest_open_full.png"));
            tile[126].collision = true;

            tile[127] = new Tile();
            tile[127].image = ImageIO.read(new File("src/assets/mapassets/misc/box.png"));
            tile[127].collision = true;

            tile[128] = new Tile();
            tile[128].image = ImageIO.read(new File("src/assets/mapassets/misc/boxes_stacked.png"));
            tile[128].collision = true;

            tile[129] = new Tile();
            tile[129].image = ImageIO.read(new File("src/assets/mapassets/misc/darkness_bottom.png"));
            tile[129].collision = false;

            tile[130] = new Tile();
            tile[130].image = ImageIO.read(new File("src/assets/mapassets/misc/darkness_left.png"));
            tile[130].collision = false;

            tile[131] = new Tile();
            tile[131].image = ImageIO.read(new File("src/assets/mapassets/misc/darkness_right.png"));
            tile[131].collision = false;

            tile[132] = new Tile();
            tile[132].image = ImageIO.read(new File("src/assets/mapassets/misc/darkness_top.png"));
            tile[132].collision = false;

            tile[133] = new Tile();
            tile[133].image = ImageIO.read(new File("src/assets/mapassets/misc/gargoyle_mid_top_left.png"));
            tile[133].collision = false;

            tile[134] = new Tile();
            tile[134].image = ImageIO.read(new File("src/assets/mapassets/misc/gargoyle_mid_top_right.png"));
            tile[134].collision = false;

            tile[135] = new Tile();
            tile[135].image = ImageIO.read(new File("src/assets/mapassets/misc/gargoyle_top_1.png"));
            tile[135].collision = false;

            tile[136] = new Tile();
            tile[136].image = ImageIO.read(new File("src/assets/mapassets/misc/gargoyle_top_2.png"));
            tile[136].collision = false;

            tile[137] = new Tile();
            tile[137].image = ImageIO.read(new File("src/assets/mapassets/misc/skull.png"));
            tile[137].collision = false;

            tile[138] = new Tile();
            tile[138].image = ImageIO.read(new File("src/assets/mapassets/misc/torch_1.png"));
            tile[138].collision = false;

            tile[139] = new Tile();
            tile[139].image = ImageIO.read(new File("src/assets/mapassets/misc/torch_2.png"));
            tile[139].collision = false;
            
            tile[140] = new Tile();
            tile[140].image = ImageIO.read(new File("src/assets/mapassets/misc/torch_3.png"));
            tile[140].collision = false;

            tile[141] = new Tile();
            tile[141].image = ImageIO.read(new File("src/assets/mapassets/misc/torch_4.png"));
            tile[141].collision = false;

            tile[142] = new Tile();
            tile[142].image = ImageIO.read(new File("src/assets/mapassets/misc/torch_5.png"));
            tile[142].collision = false;

            tile[143] = new Tile();
            tile[143].image = ImageIO.read(new File("src/assets/mapassets/misc/torch_6.png"));
            tile[143].collision = false;

            tile[144] = new Tile();
            tile[144].image = ImageIO.read(new File("src/assets/mapassets/misc/torch_7.png"));
            tile[144].collision = false;

            tile[145] = new Tile();
            tile[145].image = ImageIO.read(new File("src/assets/mapassets/misc/torch_8.png"));
            tile[145].collision = false;

            tile[146] = new Tile();
            tile[146].image = ImageIO.read(new File("src/assets/mapassets/misc/torch_no_flame.png"));
            tile[146].collision = false;

            tile[147] = new Tile();
            tile[147].image = ImageIO.read(new File("src/assets/air.png")); //barrier air
            tile[147].collision = true;

            tile[148] = new Tile();
            tile[148].image = ImageIO.read(new File("src/assets/mapassets/floor/floor_plain.png"));
            tile[148].collision = false;

            tile[149] = new Tile();
            tile[149].image = ImageIO.read(new File("src/assets/mapassets/floor/floor_ladder.png"));
            tile[149].collision = false;

        }catch(IOException e) {
            e.printStackTrace();
        }
    }
    public void loadMap(String map) {
        
        try{
             
            FileReader is = new FileReader(map); 
            @SuppressWarnings("resource")
            BufferedReader br = new BufferedReader(is);

            int col = 0;
            int row = 0;

            String line;
            
            while ((line = br.readLine()) != null && row<gp.maxWorldRow) {
                // System.out.println("linea :"+row+"-"+line);

                String numbers[] = line.split(" ");

                for (col=0; col < gp.maxWorldCol; col++) {
                    mapTileNum[col][row] = Integer.parseInt(numbers[col]);
                }

                row++;
            }
            

        }catch(Exception e){
            System.out.println("You wish it worked");
        }
    }
    public void draw(Graphics2D g2) {

        int worldCol = 0;
        int worldRow = 0;  

        while(worldCol < gp.maxWorldCol && worldRow < gp.maxWorldRow) {
            
            int tileNum = mapTileNum[worldCol][worldRow];
            
            int worldX = worldCol * gp.tileSize;
            int worldY = worldRow * gp.tileSize;
            int screenX = worldX - gp.player.worldX + gp.player.screenX;
            int screenY = worldY - gp.player.worldY + gp.player.screenY;

            if (worldX + gp.tileSize > gp.player.worldX - gp.player.screenX &&
                worldX - gp.tileSize < gp.player.worldX + gp.player.screenX && 
                worldY + gp.tileSize > gp.player.worldY - gp.player.screenY &&
                worldY - gp.tileSize < gp.player.worldY + gp.player.screenY) {
                    g2.drawImage(tile[tileNum].image, screenX, screenY, gp.tileSize, gp.tileSize, null);
                }
            worldCol++;

            if(worldCol == gp.maxWorldCol) {
                worldCol = 0;
                worldRow++;
            }
            
            
            
        }
        
    }
}
