package main;

import java.awt.event.*;
import java.util.ArrayList;

public class MouseInput implements MouseListener, MouseMotionListener {
    int mouseX;
    int mouseY;
    GamePanel gp;

    public boolean inventoryDrawn = false;

    public void update() {
        // System.out.println(mouseX + " " + mouseY);
        if (gp.ui.titleScreenState == 0) {
            if (mouseX > gp.ui.getXforCenteredText("catacomb") / 4
                    && mouseX < gp.ui.getXforCenteredText("catacomb") + (gp.tileSize * 5)) {
                if (mouseY > gp.ui.newGameY + ((gp.tileSize / 2) - 2)
                        && mouseY < gp.ui.newGameY + (gp.tileSize + (gp.tileSize / 2) - 2)) {
                    gp.ui.commandNum = 0;

                } else if (mouseY > gp.ui.loadGameY + ((gp.tileSize / 2) - 2)
                        && mouseY < gp.ui.loadGameY + (gp.tileSize + (gp.tileSize / 2) - 2)) {

                    gp.ui.commandNum = 1;

                } else if (mouseY > gp.ui.settingsY + ((gp.tileSize / 2) - 2)
                        && mouseY < gp.ui.settingsY + (gp.tileSize + (gp.tileSize / 2) - 2)) {

                    gp.ui.commandNum = 2;

                } else if (mouseY > gp.ui.quitGameY + ((gp.tileSize / 2) - 2)
                        && mouseY < gp.ui.quitGameY + (gp.tileSize + (gp.tileSize / 2) - 2)) {

                    gp.ui.commandNum = 3;
                } else {
                    gp.ui.commandNum = -1;
                }
            }
        } else if (gp.ui.titleScreenState == 1) {
            if (mouseX > gp.ui.getXforCenteredText("select a class")
                    && mouseX < gp.ui.getXforCenteredText("select a class") + (gp.tileSize * 5)) {
                if (mouseY > gp.ui.fighterClassY + ((gp.tileSize / 2) - 2)
                        && mouseY < gp.ui.fighterClassY + (gp.tileSize + (gp.tileSize / 2) - 2)) {

                    gp.ui.commandNum = 0;
                } else if (mouseY > gp.ui.thiefClassY + ((gp.tileSize / 2) - 2)
                        && mouseY < gp.ui.thiefClassY + (gp.tileSize + (gp.tileSize / 2) - 2)) {

                    gp.ui.commandNum = 1;
                } else if (mouseY > gp.ui.sorcererClassY + ((gp.tileSize / 2) - 2)
                        && mouseY < gp.ui.sorcererClassY + (gp.tileSize + (gp.tileSize / 2) - 2)) {

                    gp.ui.commandNum = 2;
                } else if (mouseY > gp.ui.cancelClassY + ((gp.tileSize / 2) - 2)
                        && mouseY < gp.ui.cancelClassY + (gp.tileSize + (gp.tileSize / 2) - 2)) {

                    gp.ui.commandNum = 3;
                } else {
                    gp.ui.commandNum = -1;
                }
            }
        } else if (gp.gameState == gp.inventoryState) {
            if (inventoryDrawn == false) {
                gp.repaint();
                inventoryDrawn = true;
            } else if (inventoryDrawn == true) {
                while (gp.gameState == gp.inventoryState) {
                    System.out.println(gp.ui.currentSlot[0] + gp.ui.currentSlot[1]);
                    for (int i = 0; i < gp.ui.slotLocationsMaxX.length; i++) {
                        if (gp.ui.slotLocationsMinX[i] < mouseX && gp.ui.slotLocationsMaxX[i] > mouseX) {
                            if (gp.ui.slotLocationsMinY[i] + (gp.tileSize / 2) < mouseY
                                    && gp.ui.slotLocationsMaxY[i] + ((gp.tileSize / 2) - (gp.tileSize / 8)) > mouseY) {
                                gp.ui.currentSlot[0] = gp.ui.slotLocationsMinX[i];
                                gp.ui.currentSlot[1] = gp.ui.slotLocationsMinY[i];
                                gp.ui.highlightInventorySlot(i);
                            }
                        } else {

                        }
                    }
                }
            }
        } else if (gp.gameState == gp.pauseState) {
            if (mouseX > gp.ui.getXforCenteredText("catacomb") / 4
                    && mouseX < gp.ui.getXforCenteredText("catacomb") + (gp.tileSize * 5)) {
                if (mouseY > gp.ui.resumeY + ((gp.tileSize / 2) - 2)
                        && mouseY < gp.ui.resumeY + (gp.tileSize + (gp.tileSize / 2) - 2)) {
                    gp.ui.commandNum = 0;

                } else if (mouseY > gp.ui.saveGameY + ((gp.tileSize / 2) - 2)
                        && mouseY < gp.ui.saveGameY + (gp.tileSize + (gp.tileSize / 2) - 2)) {

                    gp.ui.commandNum = 1;

                } else if (mouseY > gp.ui.settingsY + ((gp.tileSize / 2) - 2)
                        && mouseY < gp.ui.settingsY + (gp.tileSize + (gp.tileSize / 2) - 2)) {

                    gp.ui.commandNum = 2;

                } else if (mouseY > gp.ui.quitGameY + ((gp.tileSize / 2) - 2)
                        && mouseY < gp.ui.quitGameY + (gp.tileSize + (gp.tileSize / 2) - 2)) {

                    gp.ui.commandNum = 3;
                } else {
                    gp.ui.commandNum = -1;
                }
            }
        }
    }

    public MouseInput(GamePanel gp) {
        this.gp = gp;

        main.Main.window.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseMoved(MouseEvent e) {
                mouseX = e.getX();
                mouseY = e.getY();
            }
        });

        main.Main.window.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                mouseX = e.getX();
                mouseY = e.getY();
                if (gp.ui.titleScreenState == 0) {
                    if (mouseX > gp.ui.getXforCenteredText("Catacomb") / 4
                            && mouseX < gp.ui.getXforCenteredText("Catacomb") + (gp.tileSize * 5)) {
                        if (mouseY > gp.ui.newGameY + ((gp.tileSize / 2) - 2)
                                && mouseY < gp.ui.newGameY + (gp.tileSize + (gp.tileSize / 2) - 2)) {
                            // proceed to class selection when new game button is clicked
                            if (e.getButton() == MouseEvent.BUTTON1) {
                                gp.ui.titleScreenState = 1;
                            }
                        } else if (mouseY > gp.ui.loadGameY + ((gp.tileSize / 2) - 2)
                                && mouseY < gp.ui.loadGameY + (gp.tileSize + (gp.tileSize / 2) - 2)) {
                            // do nothing when load game button is clicked

                        } else if (mouseY > gp.ui.settingsY + ((gp.tileSize / 2) - 2)
                                && mouseY < gp.ui.settingsY + (gp.tileSize + (gp.tileSize / 2) - 2)) {
                            // do nothing when settings button is clicked

                        } else if (mouseY > gp.ui.quitGameY + ((gp.tileSize / 2) - 2)
                                && mouseY < gp.ui.quitGameY + (gp.tileSize + (gp.tileSize / 2) - 2)) {
                            // exit the game when quit game button is clicked
                            if (e.getButton() == MouseEvent.BUTTON1) {
                                main.Main.window.dispose();
                                System.exit(0);
                            }

                        }
                    }

                } else if (gp.ui.titleScreenState == 1) {
                    if (mouseX > gp.ui.getXforCenteredText("select a class")
                            && mouseX < gp.ui.getXforCenteredText("select a class") + (gp.tileSize * 5)) {
                        if (mouseY > gp.ui.fighterClassY + ((gp.tileSize / 2) - 2)
                                && mouseY < gp.ui.fighterClassY + (gp.tileSize + (gp.tileSize / 2) - 2)) {
                            if (e.getButton() == MouseEvent.BUTTON1) {
                                gp.player.classType = "Fighter";
                                gp.gameState = gp.playState;
                                gp.ui.titleScreenState = -1;
                            }

                        } else if (mouseY > gp.ui.thiefClassY + ((gp.tileSize / 2) - 2)
                                && mouseY < gp.ui.thiefClassY + (gp.tileSize + (gp.tileSize / 2) - 2)) {
                            if (e.getButton() == MouseEvent.BUTTON1) {
                                gp.player.classType = "Thief";
                                gp.gameState = gp.playState;
                                gp.ui.titleScreenState = -1;
                            }

                        } else if (mouseY > gp.ui.sorcererClassY + ((gp.tileSize / 2) - 2)
                                && mouseY < gp.ui.sorcererClassY + (gp.tileSize + (gp.tileSize / 2) - 2)) {
                            if (e.getButton() == MouseEvent.BUTTON1) {
                                gp.player.classType = "Sorcerer";
                                gp.gameState = gp.playState;
                                gp.ui.titleScreenState = -1;
                            }

                        } else if (mouseY > gp.ui.cancelClassY + ((gp.tileSize / 2) - 2)
                                && mouseY < gp.ui.cancelClassY + (gp.tileSize + (gp.tileSize / 2) - 2)) {
                            if (e.getButton() == MouseEvent.BUTTON1) {
                                gp.ui.titleScreenState = 0;
                            }

                        }
                    }
                }
                if (gp.gameState == gp.playState) {
                    if (e.getButton() == MouseEvent.BUTTON1) {
                        gp.player.attacking = true;
                    }

                } else if (gp.gameState == gp.inventoryState) {
                    while (gp.gameState == gp.inventoryState) {
                        if (gp.ui.descriptionPreview == true) {
                            if (e.getButton() == MouseEvent.BUTTON1) {
                                gp.ui.descriptionPreview = false;
                                gp.repaint();
                            }
                        }
                        for (int i = 0; i < gp.ui.slotLocationsMaxX.length; i++) {
                            if (gp.ui.slotLocationsMinX[i] < mouseX && gp.ui.slotLocationsMaxX[i] > mouseX) {
                                if (gp.ui.slotLocationsMinY[i] + (gp.tileSize / 2) < mouseY
                                        && gp.ui.slotLocationsMaxY[i]
                                                + ((gp.tileSize / 2) - (gp.tileSize / 8)) > mouseY) {
                                    if (gp.ui.descriptionPreview == false) {
                                        if (e.getButton() == MouseEvent.BUTTON1) {
                                            gp.ui.descriptionPreview = true;
                                        }
                                    }
                                }
                            }

                        }
                    }

                } else if (gp.gameState == gp.pauseState) {
                    if (mouseX > gp.ui.getXforCenteredText("catacomb") / 4
                            && mouseX < gp.ui.getXforCenteredText("catacomb") + (gp.tileSize * 5)) {
                        if (gp.ui.commandNum == 0) { // resume
                            if (e.getButton() == MouseEvent.BUTTON1) {
                                gp.gameState = gp.playState;
                            }
                        } else if (gp.ui.commandNum == 0) { // save
                            // do nothing
                            if (e.getButton() == MouseEvent.BUTTON1) {

                            }
                        } else if (gp.ui.commandNum == 2) { // settings
                            // do nothing
                            if (e.getButton() == MouseEvent.BUTTON1) {

                            }

                        } else if (gp.ui.commandNum == 3) { // quit game
                            // exit the game when quit game button is clicked
                            if (e.getButton() == MouseEvent.BUTTON1) {
                                main.Main.window.dispose();
                                System.exit(0);
                            }
                        }

                    }
                }
            }
        });
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {

    }

    @Override
    public void mouseMoved(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }
}
