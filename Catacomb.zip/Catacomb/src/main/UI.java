package main;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;

import java.awt.image.BufferedImage;
import java.util.ArrayList;

import entity.Entity;
import object.OBJ_Heart;

public class UI {

    GamePanel gp;
    BufferedImage heart_full, heart_half, heart_blank;
    Graphics2D g2;
    public Font ariel_40, ariel_bold_80;
    // BufferedImage keyImage;
    public boolean messageOn = false;
    ArrayList<String> message = new ArrayList<>();
    ArrayList<Integer> messageCounter = new ArrayList<>();
    public String currentDialogue = "";
    public int commandNum = 0;
    public int titleScreenState = 0; // first screen in title

    public boolean newGame = false;
    public boolean loadGame = false;
    public boolean settings = false;

    public int fighterClassY;
    public int thiefClassY;
    public int sorcererClassY;
    public int cancelClassY;

    public int newGameY;
    public int loadGameY;
    public int settingsY;
    public int quitGameY;
    public int saveGameY;
    public int resumeY;

    public int slotCol = 0;
    public int slotRow = 0;

    public int slotX;
    public int slotY;
    public int boxWidth;
    public int boxHeight;
    public boolean inSlot = false;
    public boolean alreadyHighlighted = false;
    public boolean descriptionPreview = false;

    public int inventoryAreaSizeX;
    public int inventoryAreaSizeY;
    public int inventoryAreaStartX;
    public int inventoryAreaStartY;

    public int slotLocationsMinX[] = new int[63];
    public int slotLocationsMaxX[] = new int[63];

    public int slotLocationsMinY[] = new int[63];
    public int slotLocationsMaxY[] = new int[63];

    int lastSlot[] = new int[2];
    int currentSlot[] = new int[2];

    public int dFrameX;
    public int dFrameY;
    public int dFrameWidth;
    public int dFrameHeight;

    public UI(GamePanel gp) {
        this.gp = gp;

        ariel_40 = new Font("Ariel", Font.PLAIN, 40);
        ariel_bold_80 = new Font("Ariel", Font.BOLD, 80);

        // CREATE HUD OBJECT
        Entity heart = new OBJ_Heart(gp);
        heart_full = heart.image;
        heart_half = heart.image2;
        heart_blank = heart.image3;

    }

    public void addMessage(String text) {

        message.add(text);
        messageCounter.add(0);

    }

    public void draw(Graphics2D g2) {

        this.g2 = g2;

        g2.setFont(ariel_bold_80);
        g2.setColor(Color.white);
        if (gp.gameState == gp.titleState) {
            drawTitleScreen();
        }
        if (gp.gameState == gp.playState) {
            drawPlayerLife();
            drawMessage();
        }
        if (gp.gameState == gp.pauseState) {
            drawPauseScreen();
            drawPlayerLife();
        }
        if (gp.gameState == gp.dialogueState) {
            drawDialogueScreen();
            drawPlayerLife();
        }
        if (gp.gameState == gp.characterState) {
            drawCharacterScreen();
        }
        if (gp.gameState == gp.inventoryState) {
            drawInventory();

        }

    }

    public void drawPlayerLife() {

        int x = gp.tileSize / 2;
        int y = gp.tileSize / 2;
        int i = 0;
        // DRAW MAX LIFE
        while (i < gp.player.maxLife / 2) {
            g2.drawImage(heart_blank, x, y, gp.tileSize, gp.tileSize, null);
            i++;
            x += gp.tileSize;
        }
        // RESET
        x = gp.tileSize / 2;
        y = gp.tileSize / 2;
        i = 0;
        while (i < gp.player.life) {
            g2.drawImage(heart_half, x, y, gp.tileSize, gp.tileSize, null);
            i++;
            if (i < gp.player.life) {
                g2.drawImage(heart_full, x, y, gp.tileSize, gp.tileSize, null);
            }
            i++;
            x += gp.tileSize;
        }
    }

    private Color crimson = new Color(185, 20, 60);
    private Color gold = new Color(255, 215, 0);

    public void drawMessage() {

        int messageX = gp.tileSize;
        int messageY = gp.tileSize * 4;
        g2.setFont(g2.getFont().deriveFont(Font.BOLD, 32F));

        for (int i = 0; i < message.size(); i++) {

            if (message.get(i) != null) {

                g2.setColor(Color.black);
                g2.drawString(message.get(i), messageX + 2, messageY + 2);

                g2.setColor(Color.white);
                g2.drawString(message.get(i), messageX, messageY);

                int counter = messageCounter.get(i) + 1;
                messageCounter.set(i, counter);

                messageY += 50;

                if (messageCounter.get(i) > 180) {
                    message.remove(i);
                    messageCounter.remove(i);
                }
            }
        }
    }

    public void drawTitleScreen() {

        if (titleScreenState == 0) {
            g2.setColor(new Color(225, 200, 155));
            g2.fillRect(0, 0, gp.screenWidth, gp.screenHeight);

            // TITLE NAME
            g2.setFont(g2.getFont().deriveFont(Font.BOLD, 96));
            String text = "Catacomb";
            int x = getXforCenteredText(text) / 4;
            int y = gp.tileSize * 3;

            g2.setColor(Color.BLACK);
            g2.drawString(text, x + 5, y + 5);

            g2.setColor(gold);
            g2.drawString(text, x, y);

            // MENU
            g2.setFont(g2.getFont().deriveFont(Font.BOLD, 48));

            text = "NEW GAME";

            y += gp.tileSize * 2;

            newGameY = y - (gp.tileSize - (gp.tileSize / 4));
            g2.setColor(crimson);
            g2.fillRoundRect(x - 8, newGameY, gp.tileSize * 5, gp.tileSize - 2, 25, 25);
            g2.setColor(gold);
            g2.drawString(text, x, y);

            if (commandNum == 0) {
                g2.setColor(crimson);
                g2.fillRoundRect(x - (gp.tileSize + 16), y - (gp.tileSize - (gp.tileSize / 4)), gp.tileSize,
                        gp.tileSize, 25, 25);
                g2.setColor(gold);
                g2.drawString(">", x - gp.tileSize, y);
                if (newGame == true) {

                }
            }

            text = "LOAD GAME";

            y += gp.tileSize;

            loadGameY = y - (gp.tileSize - (gp.tileSize / 4));
            g2.setColor(crimson);
            g2.fillRoundRect(x - 8, loadGameY, gp.tileSize * 5, gp.tileSize - 2, 25, 25);
            g2.setColor(gold);
            g2.drawString(text, x, y);

            if (commandNum == 1) {
                g2.setColor(crimson);
                g2.fillRoundRect(x - (gp.tileSize + 16), y - (gp.tileSize - (gp.tileSize / 4)), gp.tileSize,
                        gp.tileSize,
                        25, 25);
                g2.setColor(gold);
                g2.drawString(">", x - gp.tileSize, y);
            }

            text = "SETTINGS";

            y += gp.tileSize;

            settingsY = y - (gp.tileSize - (gp.tileSize / 4));
            g2.setColor(crimson);
            g2.fillRoundRect(x - 8, settingsY, gp.tileSize * 5, gp.tileSize - 2, 25, 25);
            g2.setColor(gold);
            g2.drawString(text, x, y);

            if (commandNum == 2) {
                g2.setColor(crimson);
                g2.fillRoundRect(x - (gp.tileSize + 16), y - (gp.tileSize - (gp.tileSize / 4)), gp.tileSize,
                        gp.tileSize,
                        25, 25);
                g2.setColor(gold);
                g2.drawString(">", x - gp.tileSize, y);

            } // g2.fillRoundRect(x + gp.tileSize *8, gp.tileSize * 2, gp.tileSize * 10,
              // gp.tileSize * 12, 45, 45);

            text = "QUIT GAME";

            y += gp.tileSize;

            quitGameY = y - (gp.tileSize - (gp.tileSize / 4));
            g2.setColor(crimson);
            g2.fillRoundRect(x - 8, quitGameY, gp.tileSize * 5, gp.tileSize - 2, 25, 25);
            g2.setColor(gold);
            g2.drawString(text, x, y);

            if (commandNum == 3) {
                g2.setColor(crimson);
                g2.fillRoundRect(x - (gp.tileSize + 16), y - (gp.tileSize - (gp.tileSize / 4)), gp.tileSize,
                        gp.tileSize,
                        25, 25);
                g2.setColor(gold);
                g2.drawString(">", x - gp.tileSize, y);
            }
        } else if (titleScreenState == 1) {
            // color screen
            g2.setColor(new Color(225, 200, 155));
            g2.fillRect(0, 0, gp.screenWidth, gp.screenHeight);

            g2.setColor(gold);
            g2.setFont(g2.getFont().deriveFont(42F));

            String text = "Select a class";

            int x = getXforCenteredText(text);
            int y = gp.tileSize * 3;
            g2.drawString(text, x, y);

            text = "Fighter";
            y += gp.tileSize * 2;

            fighterClassY = y - (gp.tileSize - (gp.tileSize / 4));
            g2.setColor(crimson);
            g2.fillRoundRect(x - 8, fighterClassY, gp.tileSize * 5, gp.tileSize - 2, 25, 25);
            g2.setColor(gold);
            g2.drawString(text, x, y);
            if (commandNum == 0) {
                g2.setColor(crimson);
                g2.fillRoundRect(x - (gp.tileSize + 16), fighterClassY, gp.tileSize,
                        gp.tileSize,
                        25, 25);
                g2.setColor(gold);
                g2.drawString(">", x - gp.tileSize, y);
            }

            text = "Thief";
            y += gp.tileSize * 1;

            thiefClassY = y - (gp.tileSize - (gp.tileSize / 4));

            g2.setColor(crimson);
            g2.fillRoundRect(x - 8, thiefClassY, gp.tileSize * 5, gp.tileSize - 2, 25, 25);
            g2.setColor(gold);
            g2.drawString(text, x, y);
            if (commandNum == 1) {
                g2.setColor(crimson);
                g2.fillRoundRect(x - (gp.tileSize + 16), thiefClassY, gp.tileSize, gp.tileSize, 25, 25);
                g2.setColor(gold);
                g2.drawString(">", x - gp.tileSize, y);
            }

            text = "Sorcerer";
            y += gp.tileSize * 1;

            sorcererClassY = y - (gp.tileSize - (gp.tileSize / 4));
            g2.setColor(crimson);
            g2.fillRoundRect(x - 8, y - (gp.tileSize - (gp.tileSize / 4)), gp.tileSize * 5, gp.tileSize - 2, 25, 25);
            g2.setColor(gold);
            g2.drawString(text, x, y);
            if (commandNum == 2) {
                g2.setColor(crimson);
                g2.fillRoundRect(x - (gp.tileSize + 16), y - (gp.tileSize - (gp.tileSize / 4)), gp.tileSize,
                        gp.tileSize,
                        25, 25);
                g2.setColor(gold);
                g2.drawString(">", x - gp.tileSize, y);
            }

            text = "Cancel";
            y += gp.tileSize * 2;

            cancelClassY = y - (gp.tileSize - (gp.tileSize / 4));
            g2.setColor(crimson);
            g2.fillRoundRect(x - 8, y - (gp.tileSize - (gp.tileSize / 4)), gp.tileSize * 5, gp.tileSize - 2, 25, 25);
            g2.setColor(gold);
            g2.drawString(text, x, y);
            if (commandNum == 3) {
                g2.setColor(crimson);
                g2.fillRoundRect(x - (gp.tileSize + 16), y - (gp.tileSize - (gp.tileSize / 4)), gp.tileSize,
                        gp.tileSize,
                        25, 25);
                g2.setColor(gold);
                g2.drawString(">", x - gp.tileSize, y);
            }
        }

    }

    public void drawPauseScreen() {

        // TITLE NAME
        g2.setFont(g2.getFont().deriveFont(Font.BOLD, 96));
        String text = "Catacomb";
        int x = getXforCenteredText(text) / 4;
        int y = gp.tileSize * 3;

        g2.setColor(Color.BLACK);
        g2.drawString(text, x + 5, y + 5);

        g2.setColor(gold);
        g2.drawString(text, x, y);

        // MENU
        g2.setFont(g2.getFont().deriveFont(Font.BOLD, 48));

        text = "RESUME";

        y += gp.tileSize * 2;

        resumeY = y - (gp.tileSize - (gp.tileSize / 4));
        g2.setColor(crimson);
        g2.fillRoundRect(x - 8, newGameY, gp.tileSize * 5, gp.tileSize - 2, 25, 25);
        g2.setColor(gold);
        g2.drawString(text, x, y);

        if (commandNum == 0) {
            g2.setColor(crimson);
            g2.fillRoundRect(x - (gp.tileSize + 16), y - (gp.tileSize - (gp.tileSize / 4)), gp.tileSize,
                    gp.tileSize, 25, 25);
            g2.setColor(gold);
            g2.drawString(">", x - gp.tileSize, y);
            if (newGame == true) {

            }
        }

        text = "SAVE";

        y += gp.tileSize;

        saveGameY = y - (gp.tileSize - (gp.tileSize / 4));
        g2.setColor(crimson);
        g2.fillRoundRect(x - 8, loadGameY, gp.tileSize * 5, gp.tileSize - 2, 25, 25);
        g2.setColor(gold);
        g2.drawString(text, x, y);

        if (commandNum == 1) {
            g2.setColor(crimson);
            g2.fillRoundRect(x - (gp.tileSize + 16), y - (gp.tileSize - (gp.tileSize / 4)), gp.tileSize,
                    gp.tileSize,
                    25, 25);
            g2.setColor(gold);
            g2.drawString(">", x - gp.tileSize, y);
        }

        text = "SETTINGS";

        y += gp.tileSize;

        settingsY = y - (gp.tileSize - (gp.tileSize / 4));
        g2.setColor(crimson);
        g2.fillRoundRect(x - 8, settingsY, gp.tileSize * 5, gp.tileSize - 2, 25, 25);
        g2.setColor(gold);
        g2.drawString(text, x, y);

        if (commandNum == 2) {
            g2.setColor(crimson);
            g2.fillRoundRect(x - (gp.tileSize + 16), y - (gp.tileSize - (gp.tileSize / 4)), gp.tileSize,
                    gp.tileSize,
                    25, 25);
            g2.setColor(gold);
            g2.drawString(">", x - gp.tileSize, y);

        }

        text = "QUIT";

        y += gp.tileSize;

        quitGameY = y - (gp.tileSize - (gp.tileSize / 4));
        g2.setColor(crimson);
        g2.fillRoundRect(x - 8, quitGameY, gp.tileSize * 5, gp.tileSize - 2, 25, 25);
        g2.setColor(gold);
        g2.drawString(text, x, y);

        if (commandNum == 3) {
            g2.setColor(crimson);
            g2.fillRoundRect(x - (gp.tileSize + 16), y - (gp.tileSize - (gp.tileSize / 4)), gp.tileSize,
                    gp.tileSize,
                    25, 25);
            g2.setColor(gold);
            g2.drawString(">", x - gp.tileSize, y);
        }
        g2.drawString(text, x, y);
    }

    public void drawDialogueScreen() {
        // DIALOGUE WINDOW
        int x = gp.tileSize * 6;
        int y = gp.screenHeight / 2 + gp.tileSize;
        int width = gp.screenWidth - (gp.tileSize * 11);
        int height = gp.tileSize * 4;

        drawSubWindow(x, y, width, height);

        x += gp.tileSize;
        y += gp.tileSize;
        g2.setFont(gp.ui.ariel_40);

        for (String line : currentDialogue.split("\n")) {
            g2.drawString(line, x, y);
            y += 40;
        }
    }

    public void drawCharacterScreen() {

        // CREATE A FRAME
        final int frameX = gp.tileSize * 2;
        final int frameY = gp.tileSize;
        final int frameWidth = gp.tileSize * 6;
        final int frameHeight = gp.tileSize * 10;
        drawSubWindow(frameX, frameY, frameWidth, frameHeight);

        // TEXT
        g2.setColor(Color.black);
        g2.setFont(g2.getFont().deriveFont(32F));

        int textX = frameX + gp.tileSize / 2;
        int textY = frameY + gp.tileSize;

        final int lineHeight = 35;

        // NAMES
        g2.drawString("Level", textX, textY);
        textY += lineHeight;
        g2.drawString("Life", textX, textY);
        textY += lineHeight;
        g2.drawString("Strength", textX, textY);
        textY += lineHeight;
        g2.drawString("Dexterity", textX, textY);
        textY += lineHeight;
        g2.drawString("Attack", textX, textY);
        textY += lineHeight;
        g2.drawString("Defense", textX, textY);
        textY += lineHeight;
        g2.drawString("Exp", textX, textY);
        textY += lineHeight;
        g2.drawString("Next Level", textX, textY);
        textY += lineHeight;
        g2.drawString("Coin", textX, textY);
        textY += lineHeight + 15;
        g2.drawString("Weapon", textX, textY);
        textY += lineHeight + 20;
        g2.drawString("Shield", textX, textY);
        textY += lineHeight;

        // VALUES
        int tailX = (frameX + frameWidth) - gp.tileSize / 2;
        // RESET textY
        textY = frameY + gp.tileSize;
        String value;

        value = String.valueOf(gp.player.level);
        textX = getXforAllignToRight(value, tailX);
        g2.drawString(value, textX, textY);
        textY += lineHeight;

        value = String.valueOf(gp.player.life + "/" + gp.player.maxLife);
        textX = getXforAllignToRight(value, tailX);
        g2.drawString(value, textX, textY);
        textY += lineHeight;

        value = String.valueOf(gp.player.strength);
        textX = getXforAllignToRight(value, tailX);
        g2.drawString(value, textX, textY);
        textY += lineHeight;

        value = String.valueOf(gp.player.dexterity);
        textX = getXforAllignToRight(value, tailX);
        g2.drawString(value, textX, textY);
        textY += lineHeight;

        value = String.valueOf(gp.player.attack);
        textX = getXforAllignToRight(value, tailX);
        g2.drawString(value, textX, textY);
        textY += lineHeight;

        value = String.valueOf(gp.player.defense);
        textX = getXforAllignToRight(value, tailX);
        g2.drawString(value, textX, textY);
        textY += lineHeight;

        value = String.valueOf(gp.player.exp);
        textX = getXforAllignToRight(value, tailX);
        g2.drawString(value, textX, textY);
        textY += lineHeight;

        value = String.valueOf(gp.player.fixedNextLevelExp);
        textX = getXforAllignToRight(value, tailX);
        g2.drawString(value, textX, textY);
        textY += lineHeight;

        value = String.valueOf(gp.player.coin);
        textX = getXforAllignToRight(value, tailX);
        g2.drawString(value, textX, textY);
        textY += lineHeight;

        g2.drawImage(gp.player.currentWeapon.facingSouth, tailX - gp.tileSize, textY - 15, gp.tileSize, gp.tileSize,
                null);
        textY += gp.tileSize;
        g2.drawImage(gp.player.currentShield.facingSouth, tailX - gp.tileSize, textY - 15, gp.tileSize, gp.tileSize,
                null);
    }

    public void drawInventoryCharacterScreen() {

        // CREATE A FRAME
        final int frameX = gp.tileSize * 1;
        final int frameY = gp.tileSize * 3;
        final int frameWidth = gp.tileSize * 6;
        final int frameHeight = gp.tileSize * 10 + (gp.tileSize / 2);
        drawSubWindow(frameX, frameY, frameWidth, frameHeight);

        // TEXT
        g2.setColor(Color.black);
        g2.setFont(g2.getFont().deriveFont(32F));

        int textX = frameX + gp.tileSize / 2;
        int textY = frameY + gp.tileSize;

        final int lineHeight = 35;

        // NAMES
        g2.drawString("Level", textX, textY);
        textY += lineHeight;
        g2.drawString("Life", textX, textY);
        textY += lineHeight;
        g2.drawString("Strength", textX, textY);
        textY += lineHeight;
        g2.drawString("Dexterity", textX, textY);
        textY += lineHeight;
        g2.drawString("Attack", textX, textY);
        textY += lineHeight;
        g2.drawString("Defense", textX, textY);
        textY += lineHeight;
        g2.drawString("Exp", textX, textY);
        textY += lineHeight;
        g2.drawString("Next Level", textX, textY);
        textY += lineHeight;
        g2.drawString("Coin", textX, textY);
        textY += lineHeight + 15;
        g2.drawString("Weapon", textX, textY);
        textY += lineHeight + 20;
        g2.drawString("Shield", textX, textY);
        textY += lineHeight;

        // VALUES
        int tailX = (frameX + frameWidth) - gp.tileSize / 2;
        // RESET textY
        textY = frameY + gp.tileSize;
        String value;

        value = String.valueOf(gp.player.level);
        textX = getXforAllignToRight(value, tailX);
        g2.drawString(value, textX, textY);
        textY += lineHeight;

        value = String.valueOf(gp.player.life + "/" + gp.player.maxLife);
        textX = getXforAllignToRight(value, tailX);
        g2.drawString(value, textX, textY);
        textY += lineHeight;

        value = String.valueOf(gp.player.strength);
        textX = getXforAllignToRight(value, tailX);
        g2.drawString(value, textX, textY);
        textY += lineHeight;

        value = String.valueOf(gp.player.dexterity);
        textX = getXforAllignToRight(value, tailX);
        g2.drawString(value, textX, textY);
        textY += lineHeight;

        value = String.valueOf(gp.player.attack);
        textX = getXforAllignToRight(value, tailX);
        g2.drawString(value, textX, textY);
        textY += lineHeight;

        value = String.valueOf(gp.player.defense);
        textX = getXforAllignToRight(value, tailX);
        g2.drawString(value, textX, textY);
        textY += lineHeight;

        value = String.valueOf(gp.player.exp);
        textX = getXforAllignToRight(value, tailX);
        g2.drawString(value, textX, textY);
        textY += lineHeight;

        value = String.valueOf(gp.player.fixedNextLevelExp);
        textX = getXforAllignToRight(value, tailX);
        g2.drawString(value, textX, textY);
        textY += lineHeight;

        value = String.valueOf(gp.player.coin);
        textX = getXforAllignToRight(value, tailX);
        g2.drawString(value, textX, textY);
        textY += lineHeight;

        g2.drawImage(gp.player.currentWeapon.facingSouth, tailX - gp.tileSize, textY - 15, gp.tileSize, gp.tileSize,
                null);
        textY += gp.tileSize;
        g2.drawImage(gp.player.currentShield.facingSouth, tailX - gp.tileSize, textY - 15, gp.tileSize, gp.tileSize,
                null);
    }

    public void drawInventory() {
        int frameX = 25;
        int frameY = 25;
        int frameWidth = (gp.maxScreenCol * gp.tileSize) - gp.tileSize;
        int frameHeight = (gp.maxScreenRow * gp.tileSize) - gp.tileSize;

        drawSubWindow(frameX, frameY, frameWidth, frameHeight);

        frameX = gp.tileSize;
        frameY = gp.tileSize * 1;
        frameWidth = gp.tileSize * 5;
        frameHeight = gp.tileSize * 2;
        drawSubWindow(frameX, frameY, frameWidth, frameHeight);
        g2.setFont(g2.getFont().deriveFont(46F));
        g2.drawString("Player Stats", frameX + (gp.tileSize / 2), (frameY * 2) + (gp.tileSize / 2));

        drawInventoryCharacterScreen();

        // draw cursor

        final int slotXstart = (frameX + frameWidth) + (gp.tileSize / 2);
        final int slotYstart = (frameY + frameHeight) + 5;
        slotX = slotXstart;
        slotY = slotYstart;

        inventoryAreaStartX = slotXstart;
        inventoryAreaStartY = slotYstart;

        // draw cursor
        boxWidth = gp.tileSize + (gp.tileSize / 2);
        boxHeight = gp.tileSize + (gp.tileSize / 2);

        // draw inventory boxes

        for (int i = 0; i < entity.Entity.inventorySize; i++) {
            slotLocationsMinX[i] = slotX;
            slotLocationsMaxX[i] = slotX + boxWidth + (gp.tileSize / 8);

            slotLocationsMinY[i] = slotY;
            slotLocationsMaxY[i] = slotY + boxHeight + (gp.tileSize / 8);

            g2.drawRoundRect(slotX, slotY, boxWidth, boxHeight, 10, 10);

            slotX += boxWidth + (gp.tileSize / 8);
            if (i == 8 || i == 17 || i == 26 || i == 35 || i == 44 || i == 53 || i == 62) {

                slotX = slotXstart;
                slotY += boxHeight + (gp.tileSize / 8);

            }

        }
        inventoryAreaSizeX = boxWidth * 14;
        inventoryAreaSizeY = boxHeight * 7;

        // description frame

        dFrameX = inventoryAreaSizeX + (gp.tileSize / 2);
        dFrameY = frameY + frameHeight;
        dFrameWidth = frameWidth;
        dFrameHeight = frameHeight * 3;

        // description text
        if (descriptionPreview == false) {
            drawDescription();
            drawSubWindow(dFrameX, dFrameY, dFrameWidth, dFrameHeight);
        }

        slotX = slotXstart;
        slotY = slotYstart;
        // draw player items
        for (int i = 0; i < gp.player.inventory.size(); i++) {

            g2.drawImage(gp.player.inventory.get(i).facingSouth, slotX, slotY, boxWidth, boxHeight, null);

            slotX += boxWidth + (gp.tileSize / 8);
            if (i == 8 || i == 17 || i == 26 || i == 35 || i == 44 || i == 53 || i == 62) {
                slotX = slotXstart;
                slotY += boxHeight + (gp.tileSize / 8);
            }

        }
        gp.ui.currentSlot[0] = gp.ui.slotLocationsMinX[0];
        gp.ui.currentSlot[1] = gp.ui.slotLocationsMinY[0];

        gp.ui.lastSlot[0] = gp.ui.slotLocationsMinX[0];
        gp.ui.lastSlot[1] = gp.ui.slotLocationsMinX[0];

    }

    public void drawSubWindow(int x, int y, int width, int height) {

        Color cTan = new Color(210, 180, 140, 200);
        g2.setColor(cTan);
        g2.fillRoundRect(x, y, width, height, 35, 35);

        Color cBlack = new Color(0, 0, 0);
        g2.setColor(cBlack);
        g2.setStroke(new BasicStroke(5));
        g2.drawRoundRect(x + 5, y + 5, width - 10, height - 10, 25, 25);
    }

    public int getXforCenteredText(String text) {
        int length = (int) g2.getFontMetrics().getStringBounds(text, g2).getWidth();
        int x = gp.screenWidth / 2 - length / 2;
        return x;
    }

    public int getXforAllignToRight(String text, int tailX) {
        int length = (int) g2.getFontMetrics().getStringBounds(text, g2).getWidth();
        int x = tailX - length;
        return x;
    }

    public int itemIndex() {
        int row = 0;
        int col = 0;
        if (currentSlot[0] < 520) {
            col = 1;
        } else if (currentSlot[0] < 624) {
            col = 2;
        } else if (currentSlot[0] < 728) {
            col = 3;
        } else if (currentSlot[0] < 832) {
            col = 4;
        } else if (currentSlot[0] < 936) {
            col = 5;
        } else if (currentSlot[0] < 1040) {
            col = 6;
        } else if (currentSlot[0] < 1144) {
            col = 7;
        } else if (currentSlot[0] < 1248) {
            col = 8;
        } else if (currentSlot[0] < 1248) {
            col = 8;
        } else if (currentSlot[0] < 1352) {
            col = 9;
        }

        if (currentSlot[1] < 301) {
            row = 1;
        } else if (currentSlot[1] < 405) {
            row = 2;
        } else if (currentSlot[1] < 509) {
            row = 3;
        } else if (currentSlot[1] < 613) {
            row = 4;
        } else if (currentSlot[1] < 717) {
            row = 5;
        } else if (currentSlot[1] < 821) {
            row = 6;
        } else if (currentSlot[1] < 925) {
            row = 7;
        }

        int itemIndex = col * row;
        itemIndex -= 1;
        System.out.println(itemIndex);
        return itemIndex;
    }

    public void highlightInventorySlot(int i) {

        /*
         * System.out.println("x:" + lastSlot[0] + "y:" + lastSlot[1]);
         * System.out.println("x:" + currentSlot[0] + "y:" + currentSlot[1]);
         * System.out.println("--------------");
         */
        if ((currentSlot[0] != lastSlot[0] || currentSlot[1] != lastSlot[1])) {
            gp.repaint(lastSlot[0], lastSlot[1], boxWidth, boxHeight);

            lastSlot[0] = currentSlot[0];
            lastSlot[1] = currentSlot[1];

            gp.repaint(currentSlot[0], currentSlot[1], boxWidth, boxHeight);

        }

        g2.fillRect(currentSlot[0], currentSlot[1], boxWidth, boxHeight);

    }

    public void drawDescription() {
        int textX = dFrameX + gp.tileSize / 2;
        int textY = dFrameY + gp.tileSize;
        try {

            for (String line : gp.player.inventory.get(itemIndex()).description.split("\n")) {
                g2.drawString(line, textX, textY);
                textY += 36;

                gp.repaint(dFrameX, dFrameY, dFrameWidth, dFrameHeight);

            }
        } catch (IndexOutOfBoundsException e) {

        }
    }
}
