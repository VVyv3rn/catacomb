package main;

import entity.NPC_Oldman;
import monster.undead.MON_BoundCadaver;
import monster.undead.MON_BrittleArcher;
import monster.undead.MON_CarcassFeeder;
import monster.undead.MON_DecrepitBones;
import monster.undead.MON_DismemberedCrawler;
import monster.undead.MON_GhastlyEye;
import monster.undead.MON_GiantRoyalScarab;
import monster.undead.MON_GraveRevenant;
import monster.undead.MON_MutilatedStumbler;
import monster.undead.MON_RoyalScarab;
import monster.undead.MON_SandGhoul;
import monster.undead.MON_SkitteringHand;
import monster.undead.MON_VampireBat;
import object.OBJ_Chest;
import object.OBJ_Door;
import object.OBJ_Open_Chest;
import object.OBJ_Open_Door;
import object.OBJ_Torch;

public class AssetSetter {
    
    GamePanel gp;
    


    public AssetSetter(GamePanel gp) {
        this.gp = gp;
    }

    public void setObject() {
        
         
        //COPY OBJ LOCATION SETTINGS

        for(int i = 0; i < gp.obj.length; i++) {
            if(gp.objVariant[i] != null) {
                gp.objVariant[i].worldX = gp.obj[i].worldX;
                gp.objVariant[i].worldY = gp.obj[i].worldY;
            }
            
        }
    }
    public void setNPC() {
        
        gp.npc[0] = new NPC_Oldman(gp);
        gp.npc[0].worldX = gp.tileSize * 12;
        gp.npc[0].worldY = gp.tileSize * 7;
    }
    public void setMonster() {
        int i = 0;
        gp.allMonster[i] = new MON_GraveRevenant(gp, true);
       
        i++;

        gp.allMonster[i] = new MON_BrittleArcher(gp, true);
        
        i++;
        
        gp.allMonster[i] = new MON_BoundCadaver(gp, true);
        
        i++;
        
        gp.allMonster[i] = new MON_CarcassFeeder(gp, true);
        
        i++;

        gp.allMonster[i] = new MON_DecrepitBones(gp, true);
        
        i++;

        gp.allMonster[i] = new MON_DismemberedCrawler(gp, true);
        
        i++;

        gp.allMonster[i] = new MON_GhastlyEye(gp, true);
        
        i++;

        gp.allMonster[i] = new MON_GiantRoyalScarab(gp, true);
        
        i++;

        gp.allMonster[i] = new MON_MutilatedStumbler(gp, true);
       
        i++;

        gp.allMonster[i] = new MON_RoyalScarab(gp, true);
        
        i++;
        
        gp.allMonster[i] = new MON_SandGhoul(gp, true);
        
        i++;
        
        gp.allMonster[i] = new MON_SkitteringHand(gp, true);
        
        i++;

        gp.allMonster[i] = new MON_VampireBat(gp, false);
    }
}
