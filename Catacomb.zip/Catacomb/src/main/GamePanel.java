package main;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import entity.Entity;
import entity.Player;
import tile.TileManager;

public class GamePanel extends JLabel implements Runnable {
    // GETTING SCREEN RESOLUTION
    public GraphicsDevice gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
    int resW = gd.getDisplayMode().getWidth();
    int resH = gd.getDisplayMode().getHeight();

    // SCREEN SETTINGS
    public final int originalTileSize = 16; // 16x16 tile
    public final static int scale = 4;
    public final int nonStaticScale = scale;

    public final int tileSize = originalTileSize * scale; // 48x48 tile
    public  int maxScreenCol = resW / (16 * scale);
    public  int maxScreenRow = resH / (16 * scale);
    public  int screenWidth = tileSize * maxScreenCol; // 768 pixels
    public  int screenHeight = tileSize * maxScreenRow; // 576 pixels

    // WORLD SETTINGS
    public final int maxWorldCol = 50;
    public final int maxWorldRow = 50;
    public final int maxWorldWidth = tileSize * maxWorldCol;
    public final int maxWorldHeight = tileSize * maxWorldRow;

    // fps
    int FPS = 60;
    double doubleFPS;
    double gameFPS;

    TileManager tileM = new TileManager(this);
    public KeyHandler keyH = new KeyHandler(this);
    Thread gameThread;
    public CollisionChecker cChecker = new CollisionChecker(this);
    public AssetSetter aSetter = new AssetSetter(this);
    public UI ui = new UI(this);
    public MouseInput mInput = new MouseInput(this);
    public EventHandler eHandler = new EventHandler(this);
   
        

    // ENTITY AND OBJECT
    public Player player = new Player(this, keyH);
    public Entity obj[] = new Entity[10];
    public Entity objVariant[] = new Entity[10];
    public Entity npc[] = new Entity[10];
    public Entity monster[] = new Entity[110];
    public Entity allMonster[] = new Entity[30];
    ArrayList<Entity> entityList = new ArrayList<>();

    // GAME STATE
    public int gameState;
    public final int playState = 1;
    public final int pauseState = 2;
    public final int dialogueState = 3;
    public final int characterState = 4;
    public final int inventoryState = 5;
    public final int titleState = 0;

    

    public GamePanel() {

        main.Main.window.addMouseListener(mInput);
        
        this.setPreferredSize(new Dimension(screenWidth, screenHeight));
        this.setBackground(Color.black);
        this.setDoubleBuffered(true);
        this.addKeyListener(keyH);
        this.setFocusable(true);
    }

    public void setupGame() {

        aSetter.setObject();
        aSetter.setNPC();
        aSetter.setMonster();
        gameState = titleState;

    }

    public void startGameThread() {

        gameThread = new Thread(this);
        gameThread.start();
    }

    @Override
    public void run() {

        deltaFPS();

    }

    int avgFPS;
    int lastFPS;
    int currentFPS;

    public void deltaFPS() {

        double drawInterval = 1000000000 / FPS;
        double delta = 0;
        long lastTime = System.nanoTime();
        long currentTime;
        long timer = 0;
        int drawCount = 0;

        while (gameThread != null) {
            currentTime = System.nanoTime();

            delta += (currentTime - lastTime) / drawInterval;
            timer += (currentTime - lastTime);
            lastTime = currentTime;

            if (delta >= 1) {
                update();
                repaint();
                delta--;
                drawCount++;

            }

            if (timer >= 1000000000) {
                System.out.println("FPS:" + drawCount);
                lastFPS = drawCount;
                currentFPS = lastFPS + drawCount;
                avgFPS = currentFPS / 2;
                drawCount = 0;
                timer = 0;
            }
        }
    }

    public void sleepFPS() {
        double drawInterval = 1000000000 / FPS; // 0.01666 seconds
        double nextDrawTime = System.nanoTime() + drawInterval;

        while (gameThread != null) {
            try {
                double remainingTime = nextDrawTime - System.nanoTime();
                remainingTime = remainingTime / 1000000;

                if (remainingTime < 0) {
                    remainingTime = 0;
                }

                Thread.sleep((long) remainingTime);

                nextDrawTime += drawInterval;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            update();

            repaint();
        }
    }

    public void update() {

        mInput.update();
       
        entity.Entity.randomSpawning();

        
        if (gameState == playState) {
            // PLAYER
            player.update();
            // NPC
            for (int i = 0; i < npc.length; i++) {
                if (npc[i] != null) {
                    npc[i].update();
                }
            }
            for (int i = 0; i < monster.length; i++) {
                if(monster[i] != null) {
                    if(monster[i].alive == true && monster[i].dying == false) {
                        monster[i].update();
                    }
                    if(monster[i].alive == false) {
                        monster[i] = null;
                    }
                }  
            }
        }
        if (gameState == pauseState) {
            // nothing
        }

    }

    public void paintComponent(Graphics g) {

        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        // DEBUG
        long drawStart = 0;
        if (keyH.debug == true) {
            drawStart = System.nanoTime();
        }
        // TITLESCREEN
        if (gameState == titleState) {
            ui.draw(g2);

        
        } 
        //OTHERS
        else {

            // TILE
            tileM.draw(g2);


            // ADD ENTITIES TO ENTITY LIST
            entityList.add(player);
            
            for(int i = 0; i < npc.length; i ++) {
                if(npc[i] != null) {
                    entityList.add(npc[i]);
                }
            }

            for(int i = 0; i < obj.length; i++) {
                if(obj[i] != null) {
                    entityList.add(obj[i]);
                }
            }

            for (int i = 0; i < monster.length; i++) {
                if(monster[i] != null) {
                    entityList.add(monster[i]);
                }  
            }

            // SOFT
            Collections.sort(entityList, new Comparator<Entity>() {
                @Override
                public int compare(Entity e1, Entity e2) {

                    int result = Integer.compare(e1.worldY, e2.worldY);
                    return result;
                }
            });
            
            //DRAW ENTITIES
            for(int i = 0; i < entityList.size(); i++) {
                entityList.get(i).draw(g2);
            }

            //EMPTY ENTITY LIST
            entityList.clear();


            // UI
            ui.draw(g2);

            // DEBUG
            if (keyH.debug == true) {
                long drawEnd = System.nanoTime();
                double passed = drawEnd - drawStart;

                gameFPS = 1 / (passed / 1000000000);

                

                
                g2.setColor(Color.white);
                g2.setFont(ui.ariel_40);
                g2.drawString("FPS: " + gameFPS, 10, 450);
                g2.drawString("Draw Time: " + passed / 1000000000 + " Seconds" , 10, 400);
                g2.drawString("Game State: " + gameState, 10, 350);
                g2.drawString("Damage Immune: " + player.invincible, 10, 300);
                g2.drawString("Attacking: " + player.attacking, 10, 250);
                g2.drawString("Collision active: " + player.collisionOn, 10, 200);
                g2.drawString("Coordinates: x: " + player.worldX / tileSize + " y: " + player.worldY / tileSize, 10, 550);
                g2.drawString("Facing: " + player.direction, 10, 500);
                g2.drawString("Entities Spawned " + "M:" + monster.length, 10, 600);
            }
        }

        g2.dispose();

    }
}
