package object;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import entity.Entity;

public class OBJ_Torch extends Entity {
    public OBJ_Torch() {
        super(gp);
        name = "Torch";
        try{
            walkingSouth = ImageIO.read(new File("src/assets/mapassets/misc/torch_1.png"));

        }catch(IOException e) {
            e.printStackTrace();
        }
    }
}