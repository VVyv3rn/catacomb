package object;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import entity.Entity;

public class OBJ_Door extends Entity {

    public OBJ_Door() {
        super(gp);

        name = "Door";
        try {
            walkingSouth = ImageIO.read(new File("src/assets/mapassets/wall/door/door_closed.png"));
        }catch(IOException e) {
            e.printStackTrace();
        }
        collision = true;
    }
}
