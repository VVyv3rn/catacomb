package object;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import entity.Entity;

public class OBJ_Key extends Entity {
    public OBJ_Key() {
        super(gp);
        
        name = "Key";
        description = "A golden key \nThis can be used \nto unlock things";
        try{
            facingSouth = ImageIO.read(new File("src/assets/itemassets/objects/key.png"));

        }catch(IOException e) {
            e.printStackTrace();
        }
        collision = true;
    }
}
