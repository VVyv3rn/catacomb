package object;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import entity.Entity;

public class OBJ_Open_Chest extends Entity {
    public OBJ_Open_Chest() {
        super(gp);

        name = "Open Chest";
        try {
            walkingSouth = ImageIO.read(new File("src/assets/mapassets/misc/chests/chest_open_empty.png"));
        }catch(IOException e) {
            e.printStackTrace();
        }
        collision = true;
    }
}
