package object;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import entity.Entity;

public class OBJ_Chest extends Entity{
    public OBJ_Chest() {
        super(gp);

        name = "Chest";
        try {
            walkingSouth = ImageIO.read(new File("src/assets/mapassets/misc/chests/chest_closed.png"));
        }catch(IOException e) {
            e.printStackTrace();
        }
        collision = true;
    }
}
