package object.weapon;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import entity.Entity;
import main.GamePanel;

public class WPN_Default_Sword extends Entity{

    public WPN_Default_Sword(GamePanel gp) {
        super(gp);
        
        name = "Default Sword";
        description = "An old wooden \nsword\n Attack: 1";
        try {
            facingSouth = ImageIO.read(new File("src/assets/itemassets/weapon/001.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        attackValue = 1;
    }

}
