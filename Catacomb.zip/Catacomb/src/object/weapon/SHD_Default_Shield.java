package object.weapon;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import entity.Entity;
import main.GamePanel;

public class SHD_Default_Shield extends Entity {

    public SHD_Default_Shield(GamePanel gp) {
        super(gp);

        name = "Default Shield";
        description = "An old wooden\nshield\n Defense: 1";
        try {
            facingSouth = ImageIO.read(new File("src/assets/itemassets/weapon/036.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        defenseValue = 1;
    }

}
