package object;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import entity.Entity;

public class OBJ_Open_Door extends Entity {
    public OBJ_Open_Door() {
        super(gp);

        name = "Open_Door";
        try {
            walkingSouth = ImageIO.read(new File("src/assets/mapassets/wall/door/door_open.png"));
        }catch(IOException e) {
            e.printStackTrace();
        }
        collision = false;
    }
}
